from gu906 import MicropyGPRS,crc32
from storage import MicropySTORAGE
import GL
GL.N_lock = 12
my_gprs = MicropyGPRS()
my_storage = MicropySTORAGE()

a=b'~001685)\xed\xa0$nM*|\xd3\x9a\xaa\xa5`\xa8v&\xda\xf9C!~'
a=  b'~001681\xa4\xaer-\xb1\x9a\xa2\x97-=\xbbB\xcc\xfe(*\xd8/\xd8<~'
a=b'~001671\xb8-\x90\xd5\xafKM\xacRy\x8b\x9b\xc8\xae\x03\xd7\xcc\x8e&\xce~'
a=[b'AT+CS,O+IPD,93:~008040\xbe_\x85\xb5\x1d\xa4\x05\xd2\xa2\xa4HW)\xda9\x9d\x8aU<\xf4\xc8\x0b+\x1aH\x85\x05^\xb4\xf4`\x1f\x9ay^\x18\x9a\xed\xdeg\x9bg\x05\xe6;}\x01\xb0\xe4L[nt\x12%\xae\xdb\xf2\xd3\xca\xce\xf8a43Q\x8fyt\xeeMG\xda\xc6\\\xde\x1ae\x81\xf9D\xdd\xafO\xb5~', b'AT+CNUM=?', b'AT', b'OK']
a=b'~008042+\x05\xec\x06\x84\x1b\xad\xae\xb1-fH\x13\xbf\xe6\x9e/\xdb+\x97\x10\x9f\xe45\xab\x0f}\x02C\x88ccQVx:\x14\xab\x89}\x01\xc3\x13\x98NJ\x14\x15\xa8\x11.\xfe[.\x19\x87\xf8\x06b\xde2]\x89\xb6{\xe4\xcb\xb0\x1f\xbf\t\xbc*\xe8\xdfv\xbb\x07\xa2\xbc\xdbr\xd6u\xeb1~'
a=b'~008079\xa3\xdf\t\xa2\x0b\x0c\xb3\xf9\xbf\x15\xde\xe7\xf0\x0f7\xef6w\xa3\x84\xe7\x11]\xde\xa8g!j\xd4l\xf5\xb8\\\xf3\xacz"<NvO\xc4\x1a\x9c}\x01\xd9\xa0\x87\xd4i\x1cZ\'+=H\xff\xa2\x1c\x1b\t\x03}\x02\x8c*N\xe9\xcen9\x07\x0f\x1d\xccju\x1cE+<\xbd+6h~'
GL.locks_opreate = bytearray(b'111111111111')

b=[
b'000074A4E612E3A21474959934.795201113.5941251000111111111111',
b'000088B0000009A00000099934.720680113.7272320100111111111111',
b'000087B0000008A00000089934.720680113.7272320100111111111111',
b'000086B0000007A00000079934.720680113.7272320100111111111111',
b'000083B0000006A00000069934.720680113.7272320100111111111111',
b'00007933333333444444449934.742107113.7538930100111111111111',
b'000078B0000003A00000039934.746392113.6980540100111111111111',
b'000077B0000005A00000059934.765385113.6872760100111111111111',
b'00007655555555666666669934.746382113.6814610100111111111111',
b'00007533333333444444449934.742107113.7538930100111111111111'
]
my_gprs.unpack_server_data(a)

filename = 'swipe_record.txt'
'''
my_storage.modify_info(filename,'')
for i in b:
    my_storage.modify_infos(filename,[i])

print('n_gas_info = {}'.format(my_storage.get_rows(filename)))
for i in my_storage.get_infos(filename):
    print(i)

n_pos = my_storage.get_rows(filename)
print('n_gas_info = {}'.format(n_pos))
step  = 3
if n_pos:
    for i in range(step):
        if n_pos-i >= 1:
            info = my_storage.get_info(filename,n_pos-i)
            print(info)
            my_storage.del_rows(filename,n_pos-i)
'''