# Global share data
#########################################
# tja1040.py
'''
GL.N_lock                  # variable
GL.lock_status             # variable
GL.lose_lock               # variable

N_lock = 0                  # variable
lock_status = 0            # variable
lose_lock = 0              # variable
'''
#########################################
# gu906.py
'''
GL.m                       # variable
GL.rssi                    # variable
GL.send_9012               # variable
GL.cme_error2              # variable
GL.report_tick             # variable
GL.rx_order_dat            # variable
GL.update_lcd              # variable

m = 0
rssi = 0
send_9012 = 0
cme_error2 = 0
report_tick = 0
rx_order_dat = 0
update_lcd = 0
'''
#########################################
# n303.py
'''
GL.g                       # variable
GL.gnss_buf                # variable
GL.vcc_below_14V           # variable
GL.locks_on_checks_vcc19V  # variable
GL.locks_off               # variable

g = 0
gnss_buf = 0
vcc_below_14V = 0
locks_on_checks_vcc19V = 0
locks_off = 0
'''
#########################################
# m3650b.py
'''
GL.ic_id                   # variable

ic_id = ''
'''
#########################################
# storage.py
'''
GL.ip                      # variable
GL.ic                      # variable
GL.port                    # variable
GL.pwd                     # variable

ip = 0
ic = 0
port = 0
pwd = 0
'''
#########################################
# test.py
'''
init = 0
dog = 0
lcd_update = 0

GL.init
Gl.dog
GL.lcd_update              # function
'''

debug = True

def debug_print(mess=''):
    if debug:
        print(mess)