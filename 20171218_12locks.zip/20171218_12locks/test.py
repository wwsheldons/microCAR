
from storage import MicropySTORAGE
from gu906 import MicropyGPRS
from n303 import MicropyGNSS
from usched import Sched, Poller, wait,Timeout
from tja1040 import MicropyLOCK
from lcdthread import LCD
from utime import ticks_ms,ticks_diff
from m3650b import MicropyRFID
from wdt import wdog
from beep import alarm
import pyb,GL

def str2bcd(d):
    if len(d)%2:
        d='0'+d
    out = bytearray(8)
    for i in range(0,len(d),2):
        t = d[i:i+2]
        out[int(i/2)+8-int(len(d)/2)] = (int(t[0])<<4)+int(t[1])
    return out

def stop(fTim, objSch):                                     # Stop the scheduler after fTim seconds
    yield from wait(fTim)
    objSch.stop()
'''
def robin_1s(my_lock,my_gprs):
    while True:
        GL.debug_print('check locks every 1s')
        ls = [i & 0x0f for i in GL.lock_status]
        if 4 in ls:
            GL.storage.modify_info(GL.storage.lsfn,ls.index(4)+1)
            my_lock.locks_power_off()
            GL.lcd_update('s')
            if GL.m:
                my_gprs.handle_9003()
            else:
                my_gprs.connect()
        # check locks status
        my_lock.check_locks()
        GL.dog.feed()
        yield 1
def robin_9012_thread(my_gprs,timeout=60):
    while True :
        GL.debug_print('robin_9012_thread is runing {} ---9999999999999999'.format(timeout))
        if not GL.m:
            my_gprs.connect()
        if GL.m:
            my_gprs.send_1012()

        #GL.collect()
        GL.dog.feed()
        yield 60
        #yield from wait(timeout)
'''

def check_power(my_lock,my_gnss,opt = 0):
    if not GL.g or opt:
        my_gnss.update_voltage()
    if GL.vcc_below_14V:
        GL.vcc_below_14V = False
    if GL.locks_on_checks_vcc19V:
        GL.locks_on_checks_vcc19V = False
        my_lock.locks_power_on()
        my_lock.check_locks()
    if GL.locks_off:
        GL.locks_off = False
        my_lock.locks_power_off()
def save_pos(filename):
    pos = bytearray(GL.id)+bytearray(GL.lock_status)+GL.gnss_buf
    pos[53+12+11] = 50
    n = GL.storage.get_rows(filename)
    #speed = int(bytes(GL.gnss_buf[42:45]).decode()) #---speed
    #GL.debug_print('speed is {}'.format(speed))
    '''
    if filename == GL.storage.posfn:
        if speed > 1:
            GL.storage.modify_info(filename,pos,'add')
    else:
        GL.storage.modify_info(filename,pos,'add')
    '''
    GL.storage.modify_info(filename,pos,'add')
    print('save {}th offline pos record'.format(n+1))


def robin_tick_thread(my_lock,my_gprs,my_gnss):
    while True :
        #GL.debug_print('robin_tick_threa 111111111111111111')
        ###################################################
        # check locks status
        ls = [i & 0x0f for i in GL.lock_status]
        my_lock.check_locks()
        #GL.debug_print('GL.pre_lock_status = {}'.format(GL.pre_lock_status))
        #GL.debug_print('GL.lock_status =     {}'.format(GL.lock_status))
        if GL.pre_lock_status != GL.lock_status:
            if GL.m:
                my_gprs.handle_9003()
            else:
                save_pos(GL.storage.posfn)
            GL.pre_lock_status = GL.lock_status
        # lock open or control open
        if 4 in ls or GL.gnss_buf[54:55] == b'2':
            if 4 in ls:
                GL.storage.modify_info(GL.storage.lsfn,ls.index(4)+1)
            if GL.gnss_buf[54:55] == b'2':
                GL.storage.modify_info(GL.storage.lorfn,1)
            my_lock.locks_power_off()
            GL.lcd_update('s')
            if GL.m:
                my_gprs.handle_9003()

        if not GL.m:
            my_gprs.connect()


        if GL.speed_is_zero_with_30s < 15:
            #GL.debug_print('check locks every 1s')
            GL.dog.feed()
            # check power
            check_power(my_lock,my_gnss,1)

            ####################################################
            # check the net status
            tick1 = ticks_diff(GL.report, ticks_ms())
            if tick1 > 1000*GL.report_tick:
                #GL.debug_print('robin_tick_thread  {} rrrrrrrrrrrrrrrrrrr'.format(tick1))


                my_gprs.check_csq()
                GL.dog.feed()
                my_gprs.check_phone_card()
                GL.dog.feed()
                my_gprs.rec_sms()
                GL.dog.feed()
                if GL.m:
                    my_gprs.handle_9003()
                    ##############################################
                    # upload the offline data
                    # upload the online pos data
                    '''
                    n_cur_pos = GL.storage.get_rows(GL.storage.cur_posfn)
                    print('n_cur_pos = {} and pos = {}'.format(n_cur_pos,GL.storage.get_info(GL.storage.cur_posfn,n_cur_pos)))
                    step = 3
                    if not n_cur_pos:
                        GL.m1to0 = False
                    if GL.m1to0 and n_cur_pos:
                        for i in range(step):
                            if n_cur_pos-i >= 1:
                                info = GL.storage.get_info(GL.storage.cur_posfn,n_cur_pos-i)
                                my_gprs.method1xxx(0x1003,info)
                                my_gprs.send_dats(my_gprs.tx_buf,0x1003)
                                GL.storage.del_rows(GL.storage.cur_posfn,n_cur_pos-i)
                            else:
                                GL.m1to0 = False
                        GL.dog.feed()
                    '''
                    # upload the offline pos data
                    n_pos = GL.storage.get_rows(GL.storage.posfn)
                    #GL.debug_print('n_pos = {} and pos = {}'.format(n_pos,GL.storage.get_info(GL.storage.posfn,n_pos)))
                    step = 3
                    if n_pos:
                        for i in range(step):
                            if n_pos-i >= 1:
                                info = GL.storage.get_info(GL.storage.posfn,n_pos-i)
                                my_gprs.method1xxx(0x1003,info)
                                my_gprs.send_dats(my_gprs.tx_buf,0x1003)
                                GL.storage.del_rows(GL.storage.posfn,n_pos-i)
                        GL.dog.feed()
                    # upload the offline sms opreate lock data
                    n_sms = GL.storage.get_rows(GL.storage.smsfn)
                    #GL.debug_print('n_sms = {} and sr = {}'.format(n_sms,GL.storage.get_info(GL.storage.smsfn,n_sms)))
                    if n_sms:
                        for i in range(step):
                            if n_sms-i >= 1:
                                info = GL.storage.get_info(GL.storage.smsfn,n_sms-i)
                                my_gprs.method1xxx(0x1000,info)
                                my_gprs.send_dats(my_gprs.tx_buf,0x1000)
                                GL.storage.del_rows(GL.storage.smsfn,n_sms-i)
                        GL.dog.feed()
                    # upload the offline swipe_record data
                    n_sr = GL.storage.get_rows(GL.storage.srfn)
                    #GL.debug_print('n_sr = {} and sr = {}'.format(n_sr,GL.storage.get_info(GL.storage.srfn,n_sr)))
                    step = 3
                    if n_sr:
                        for i in range(step):
                            if n_sr-i >= 1:
                                info = GL.storage.get_info(GL.storage.srfn,n_sr-i)
                                my_gprs.method1xxx(0x1000,info)
                                my_gprs.send_dats(my_gprs.tx_buf,0x1000)
                                GL.storage.del_rows(GL.storage.srfn,n_sr-i)
                        GL.dog.feed()



                GL.debug_print('handle_9003 every        {} seconds'.format(GL.report_tick))
                GL.debug_print('the GNSS signal is       {}'.format(GL.g))
                GL.debug_print('the GPRS signal is       {}'.format(GL.m))
                GL.debug_print('the lock status is       {}'.format([hex(i) for i in GL.lock_status]))
                GL.debug_print('the rssi is              {}'.format(GL.rssi))
                GL.debug_print('GL.send_9012           = {}'.format(GL.send_9012))

                GL.dog.feed()
                GL.report = ticks_ms()
            #GL.collect()
            #GL.debug_print('yield from wait(GL.report_tick)')
        tick = ticks_diff(GL.tick_60s, ticks_ms())
        if tick > 60*1000 and GL.m:
            GL.debug_print('robin_9012_thread  {}'.format(tick))
            my_gprs.send_1012()
            GL.tick_60s = ticks_ms()
        GL.dog.feed()

        GL.debug_print('GL.speed_is_zero_with_30s = {}'.format(GL.speed_is_zero_with_30s))
        yield 1
        #yield from wait(GL.report_tick)



def rfid_thread(my_lock,my_rfid,my_gprs):

    wf = Poller(my_rfid.get_id, ())
    while(True):
        reason = (yield wf())
        #GL.collect()

        if reason[1]:
            GL.debug_print('GL.ic_id =  {}'.format(GL.ic_id))
            #objSched.add_thread(alarm(1))
            alarm(1)
            # clear error on lcd
            GL.ERROR = [0]*5
            #GL.lcd_update(9) #  update line 3   #20180107
            GL.lcd_update(0) #  update line 0
            tmp = GL.storage.card_in_low()
            ###############################
            # -2 # speed is over 30kmh
            # 0 # out of gas station ranges
            # -1 # invalid card
            # 1 #can open
            # 2 # can close
            # 3 # can emergency open
            # 4 # can emergency close
            print('card_in_low return {}'.format(tmp))
            if tmp > 0:
                if tmp in [1,3]:
                    my_lock.open_locks()
                elif tmp in [2,4]:
                    my_lock.close_locks()
                else:
                    print('wrong return from GL.storage.card_in_low() {}'.format(tmp))

                if GL.m:
                    info = bytearray(GL.id)+bytearray(GL.lock_status)+GL.gnss_buf+GL.ic_id.encode()
                    info[12+53+11] = 50 #lss(12),gnss_buf 53th (b'1'--realtime,b'2'--not realtime)
                    my_gprs.method1xxx(0x1000,info)
                    my_gprs.send_dats(my_gprs.tx_buf,0x1000)
                    pyb.delay(50)
                    my_gprs.handle_9003()
                else:
                    info = bytearray(GL.id)+bytearray(GL.lock_status)+GL.gnss_buf+GL.ic_id.encode()
                    info[12+53+11] = 50 #lss(12),gnss_buf 53th (b'1'--realtime,b'2'--no realtime)
                    GL.storage.modify_info(GL.storage.srfn,info,'add')
                    GL.debug_print('offline swipe record add 1')
            else:
                #objSched.add_thread(alarm())
                '''
                if 1 in GL.ERROR[:3]:
                    alarm()
                '''
                if GL.m:
                    my_gprs.handle_900a(0x1000,GL.ic_id)

                else:
                    alarm()

            ##  lss+gnss_buf+ic_id

            #GL.storage.modify_info(GL.storage.srfn,info,'add')
            #GL.debug_print('offline swipe record add 1')
            #GL.collect()
            '''
            if GL.m:
                my_gprs.handle_900a(0x1000,GL.ic_id)
            else:
                tmp = GL.storage.card_in_low()
                ###############################
                # -2 # speed is over 30kmh
                # 0 # out of gas station ranges
                # -1 # invalid card
                # 1 #can open
                # 2 # can close
                # 3 # can emergency open
                # 4 # can emergency close
                print('card_in_low return {}'.format(tmp))
                if tmp in [1,3]:
                    my_lock.open_locks()
                elif tmp in [2,4]:
                    my_lock.close_locks()
                elif tmp <= 0:
                    #objSched.add_thread(alarm())
                    alarm()
                else:
                    print('wrong return from GL.storage.card_in_low() {}'.format(tmp))
                ##  lss+gnss_buf+ic_id
                info = bytearray(GL.id)+bytearray(GL.lock_status)+GL.gnss_buf+GL.ic_id.encode()
                info[12+53+11] = 50 #lss(12),gnss_buf 53th (b'1'--realtime,b'2'--no realtime)
                GL.storage.modify_info(GL.storage.srfn,info,'add')
                GL.debug_print('offline swipe record add 1')
                #GL.collect()
            '''
            GL.dog.feed()




def gprs_thread(my_gprs,my_lock):
    #wf0 = Timeout(0.5)
    wf = Poller(my_gprs.update, ())                        # Instantiate a Poller with 2 second timeout.

    while True:
        reason = (yield wf())
        #GL.collect()

        if reason[1]:
            print('gprs thread is runing nnnnnnnnnnnnnnnnnnnnnn')

            GL.debug_print('my_gprs.ats_dict = {}'.format(my_gprs.ats_dict))
            for order in my_gprs.ats_dict.keys():
                del my_gprs.ats_dict[order]
            if GL.SMS:
                GL.SMS = False
                my_gprs.del_sms()
            if GL.sms_storage_ip_id_port:
                GL.sms_storage_ip_id_port = False
                GL.storage.modify_info(GL.storage.ipfn,GL.ip)
                GL.storage.modify_info(GL.storage.portfn,str(GL.port))
                if len(GL.id) == 11:
                    GL.storage.modify_info(GL.storage.idfn,GL.id)
                my_gprs.send_sms(my_gprs.phone_num,'ip,id and port set finished')
                '''
                try:
                    GL.storage.modify_info(GL.storage.usfn,int(GL.storage.get_info(GL.storage.usfn),10)+1)
                except:
                    GL.storage.modify_info(GL.storage.usfn,1)
                pyb.delay(2000)
                pyb.hard_reset()
                '''
            if GL.sms_storage_pwd:
                GL.sms_storage_pwd = False
                GL.storage.modify_info(GL.storage.pwdfn,GL.pwd)
            if GL.sms_storage_phone:
                GL.sms_storage_phone = False
                GL.storage.modify_infos(GL.storage.apfn,GL.set_phone)
            if GL.sms_lock_power_on:
                GL.sms_lock_power_on = False
                my_lock.locks_power_on()
                my_lock.check_locks()
                GL.storage.modify_info(GL.storage.lsfn,'')
                my_lock.check_locks(1)   # sometime it's easy to lose lock when repower on
                my_gprs.send_sms(my_gprs.phone_num,'locks have power on')
            if GL.sms_opreat_lock:
                order = GL.sms_opreat_lock[0]
                num = GL.sms_opreat_lock[1]
                GL.sms_opreat_lock = False
                if 'open' in order:
                    order = 'open'
                    my_lock.open_locks()
                if 'close' in order:
                    order = 'close'
                    my_lock.close_locks()

                sms_info = bytearray(GL.id)+bytearray(GL.lock_status)+GL.gnss_buf+str2bcd(num)
                sms_info[53+12+11] = 50
                GL.storage.modify_info(GL.storage.smsfn,sms_info,'add')
                my_gprs.send_sms(num,'{} locks has finished'.format(order))
                GL.dog.feed()

            for order in GL.rx_order_dat.keys():
                GL.debug_print('trigger order = {}'.format(order))
                GL.dog.feed()
                if order == '9000' and (b'1' in GL.rx_order_dat['9000'] or b'2' in GL.rx_order_dat['9000']):
                    #my_lcd.start_ns_delay()
                    GL.lcd_update('s')
                if my_gprs.supported_order[order][1](my_gprs,my_lock):
                    del GL.rx_order_dat[order]
            #yield wf0()
            GL.dog.feed()


def gnss_thread(my_lock,my_gnss,my_gprs):
    wf0 = Timeout(0.5)
    wf = Poller(my_gnss.update, ())
    while True:
        reason = (yield wf())
        if reason[1]:                                       # Value has changed
            print('gnss thread is runing  gggggggggggggggggggggggggg')
            GL.debug_print('len(GL.gnss_buf) = {} and GL.gnss_buf = {}'.format(len(GL.gnss_buf),GL.gnss_buf))
            # check the control's cover whether is opend or not
            '''
                if self.control_cover.read() > 3900:
                    GL.gnss_buf[54:55] = b'2'
                if self.control_cover.read() < 300:
                    GL.gnss_buf[54:55] = b'1'
            '''
            if GL.gnss_buf[54:55] == b'2':
                my_lock.locks_power_off()
                GL.lcd_update('s')
                #objSched.add_thread(alarm(4))
                GL.storage.modify_info(GL.storage.corfn,1)
                alarm(4)
                if GL.m:
                    my_gprs.handle_9003()
                GL.dog.feed()
            ## save 10 points when online for server offline but control is not been told
            try:
                speed = int(bytes(GL.gnss_buf[42:45]).decode()) #---speed
                if not GL.m and GL.speed_is_zero_with_30s < 3:
                    save_pos(GL.storage.posfn)
                '''
                else:
                    if not GL.m1to0:
                        try:
                            n = GL.storage.get_rows(GL.storage.cur_posfn)
                        except:
                            n = 0
                        if n > 4:
                            GL.storage.del_rows(GL.storage.cur_posfn,0)
                            yield wf0()
                        save_pos(GL.storage.cur_posfn)
                        yield wf0()
                '''
            except:
                print('storage offline pos record failed')

            check_power(my_lock,my_gnss)
            GL.dog.feed()




def main():

    dog = wdog()
    GL.dog = dog

    #gc.enable()
    #GL.collect = gc.collect()
    GL.init = True
    objSched = Sched()

    ##############################
    '''
    GL.g = 0
    GL.m = 0
    GL.N_lock = 12
    GL.lock_status = [1]*GL.N_lock
    GL.ic_id = '12345678'
    '''




    my_lcd = LCD()
    GL.lcd_update =my_lcd.update
    GL.lcd_update(100) #lcd init
    my_storage = MicropySTORAGE()
    GL.storage = my_storage

    GL.speed_is_zero_with_30s = 0
    my_lock = MicropyLOCK()
    try:
        tmp_lock = int(GL.storage.get_info(GL.storage.lsfn))
    except:
        tmp_lock = 0
    if tmp_lock:
        my_lock.locks_power_off()
        GL.lock_status[tmp_lock-1] = (GL.lock_status[tmp_lock-1] & 0xf0) + 0x04
        GL.lcd_update(tmp_lock) #lcd init
    my_gprs = MicropyGPRS()
    my_gnss = MicropyGNSS()
    my_rfid = MicropyRFID()






    if not GL.storage.get_info(GL.storage.usfn):
        GL.storage.prepare()
        my_gprs.wait_set_sms()
    try:
        GL.storage.modify_info(GL.storage.usfn,int(GL.storage.get_info(GL.storage.usfn),10)+1)
    except:
        GL.storage.modify_info(GL.storage.usfn,1)

    my_gprs.connect()


    GL.debug_print('init is over.............')
    GL.debug_print('')
    GL.debug_print('')
    GL.dog.start(65535)
    GL.init = False

    GL.tick_60s = ticks_ms()
    GL.report = ticks_ms()

    objSched.add_thread(gprs_thread(my_gprs,my_lock))
    objSched.add_thread(gnss_thread(my_lock,my_gnss,my_gprs))
    objSched.add_thread(robin_tick_thread(my_lock,my_gprs,my_gnss))
    objSched.add_thread(rfid_thread(my_lock,my_rfid,my_gprs))


    objSched.run()


if __name__ == '__main__':
    main()