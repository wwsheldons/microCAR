
from gu906 import gprs_sys
from n303 import gnss_sys
import pyb
import GL
from utime import ticks_diff, ticks_ms
from m3650b import rfid_init, get_id
from lcd12864 import clc_a, set_a, update_g_m, dis, lcd_init,update_err
from tja1040 import lock_sys
from beep import alarm, beep_on,beep_init
from storage import storage_sys
from frame import haversine
from n303 import update_gnss_buf

bat_en = pyb.Pin(pyb.Pin.cpu.A15, pyb.Pin.OUT_PP)





class Implement_protocol(object):

    def __init__(self):
        GL.admin_phone = '13783601525'
        #GL.admin_phone = '13525554999'
        beep_init()
        GL.updating = 0
        GL.file_size = 0
        GL.dwl_over = 0
        GL.send_9012 = 0
        gprs_sys['init']()
        lock_sys['init']()
        gnss_sys['init']()
        rfid_init()
        lcd_init()
        GL.control_cover = pyb.ADC(pyb.Pin.cpu.A5)
        lock_sys['light_3min']()

    def update_sys_status(self):
        #self.dis(1,0,'self-check ...')
        GL.sys_busy = True
        if storage_sys['g_ls']() or GL.control_cover.read() > 3900:
            lock_sys['lp_offs']()
            if GL.m:
                gprs_sys['1003']()
            else:
                lock_sys['update_ls']()
                lss = bytearray(GL.lock_status)
                storage_sys['m_pos_record'](lss+GL.gnss_buf)
            
        lock_sys['checks']()
        gprs_sys['csq']()
        gprs_sys['phone_card']()

        update_g_m(GL.g, GL.m)
        
        GL.debug_print('the GNSS signal is    {}'.format(GL.g))
        GL.debug_print('the GPRS signal is    {}'.format(GL.m))
        GL.debug_print('the lock status is    {}'.format(GL.ls))
        GL.debug_print('the banshou status is {}'.format(GL.ws))
        GL.debug_print('the phone_card status is {}'.format(not GL.no_phone_card))
        if GL.no_phone_card:
            update_err(4)
        
        gprs_sys['recsms']()
        GL.sys_busy = False


    def self_check(self):
        
        GL.debug_print('self check is starting...')
        
        
        storage_sys['load']()
        GL.lock_status = [1]*GL.N_lock
        self.update_sys_status()
        lock_sys['ll_init']()
        GL.debug_print('the GNSS signal is    {}'.format(GL.g))
        GL.debug_print('the GPRS signal is    {}'.format(GL.m))
        GL.debug_print('the lock status is    {}'.format(GL.ls))
        GL.debug_print('the banshou status is {}'.format(GL.ws))
        GL.debug_print('the lock_status status is {}'.format(GL.lock_status))

        
        if storage_sys['g_using_times']() == 0:
            storage_sys['prep_dir']()
            storage_sys['prep_file']()
            gprs_sys['wait']()
        storage_sys['m_using_times']()

        self.handle_lock_cover()
        
        GL.debug_print('self check has finished...')
    def card_in_law(self,ic_id):
        if ic_id in GL.ic_open:
            tmp_num = GL.ic_open.index(ic_id)
            while not GL.gnss_dat_OK:
                tmp = GL.gnss_port.readline()
                gnss_sys['update_buf'](tmp)
            lat1,lon1 = gnss_sys['get_pos']()
            tmp_dis = haversine(lat1,lon1,GL.gas_latitude[tmp_num],GL.gas_longitude[tmp_num])
            #print(tmp_dis)
            #print('lat1,lon1,GL.gas_latitude[tmp_num],GL.gas_longitude[tmp_num]',lat1,lon1,GL.gas_latitude[tmp_num],GL.gas_longitude[tmp_num])
            #GL.debug_print('tmp_dis is {}, and GL.distance[tmp_num] is {}'.format(tmp_dis,GL.distance[tmp_num]))
            if tmp_dis < GL.distance[tmp_num]:
                GL.ic_using_times[tmp_num] -= 1
                if GL.ic_using_times[tmp_num] == 0:
                    storage_sys['del_group'](tmp_num)
                storage_sys['save_em']()
                return 1 #can open
            else:
                update_err(2) #out of gas station range
                GL.err1_start_time = ticks_ms()
                return -1 #out of gas station range
        elif ic_id in GL.ic_close:
            return 2 # can close
        elif ic_id in GL.emergency_close_card:
            return 4 # can emergency close
        elif ic_id in GL.emergency_open_card:
            if GL.emergency_open_card_times == 0:
                storage_sys['m_emergency_card']('')
                
                return -3 # emergency open card can be used times is 0
            else :
                GL.emergency_open_card_times -= 1
            storage_sys['m_emergency_card'](GL.emergency_open_card + '{:0>2}'.format(GL.emergency_open_card_times))
            return 3 # can emergency open
        else:
            update_err(1)  # invalid card
            return 0
    def implement_order(self, ic_id):
        operate_dict = {1:lock_sys['opens'],2:lock_sys['closes'],3:lock_sys['opens'],4:lock_sys['closes'],0:alarm,-1:alarm,-2:alarm,-3:alarm}
        if GL.m:
            gprs_sys['1000'](ic_id)
        else:
            tmp = self.card_in_law(ic_id)
            print(tmp)
            operate_dict[tmp]()
            if tmp <= 0:
                #alarm()
                GL.debug_print('card id is wrong')
                return None
            while not GL.gnss_dat_OK:
                tmp = GL.gnss_port.readline()
                update_gnss_buf(tmp)
            lock_sys['update_ls']()
            lss = bytearray(GL.lock_status)
            storage_sys['m_sw_record'](lss+GL.gnss_buf+ic_id.encode())
            storage_sys['m_sw_record'](b'\r\n')
            GL.debug_print('the lock status is    {}'.format(GL.ls))
            GL.debug_print('the banshou status is {}'.format(GL.ws))
        return 1

    def handle_rfid(self):
        beep_on()
        lock_sys['light_3min']()
        
        ic_id = get_id()
        if not ic_id:
            return None
        for i in range(5):
            update_err(i+1,0)
        GL.debug_print('rfid data is coming and its:{}'.format(ic_id))
        return self.implement_order(ic_id)
    
    def handle_lock_cover(self):
        if 4 in GL.ls or GL.control_cover.read() > 3900:
            lock_sys['lp_offs']()
            lock_sys['light_3min']()
            alarm(4)
            storage_sys['m_ls'](1)
            if GL.m:
                gprs_sys['1003']()
            else:
                lock_sys['update_ls']()
                lss = bytearray(GL.lock_status)
                storage_sys['m_pos_record'](lss+GL.gnss_buf)

    def handle_gprs(self, dat=[]):
        if dat:
            rxdat = gprs_sys['unpack'](dat)
        if GL.gprs_port.any():
            gprs_sys['recv']()
            return 1
        GL.debug_print('the data frame from server is wrong')
        return 0
