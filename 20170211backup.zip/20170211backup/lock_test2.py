import gc


from implement import Implement_protocol
from gu906 import gprs_main
import select
import pyb
import GL

from utime import ticks_ms,ticks_diff
from wdt import wdog
from lcd12864 import lcd_main
from beep import alarm

from tja1040 import lock_main
from n303 import gnss_main
from storage import storage_main


def tick3(timer):
    if GL.rfid_port.any() == 12:
        GL.check_rfid_time = 1
    timer.deinit()


def start_check_rfid(n=20):
    
    #n_us < 1073741823
    #n_us =       1000*n
    tim3 = pyb.Timer(3)
    tim3.init(prescaler=84, period=1000*n)
    tim3.callback(tick3)


def main():
    
    GL.dog = wdog()
    
    gc.enable()
    sys = Implement_protocol()
    sys.self_check()
    #lock_main['lp_ons']()
    

    start_5s = ticks_ms()
    start_1s = ticks_ms()
    start_3min = ticks_ms()
    gprs_main['conect']()
    poll = select.poll()
    poll.register(GL.rfid_port, select.POLLIN)
    poll.register(GL.gprs_port, select.POLLIN)
    poll.register(GL.gnss_port, select.POLLIN)

    start_check_rfid()
    GL.dog.start(65535)
    while True:
        GL.lock_status = [1]*12
        lock_main['checks']()
        gc.collect()
        GL.dog.feed()
if __name__ == '__main__':
    main()
