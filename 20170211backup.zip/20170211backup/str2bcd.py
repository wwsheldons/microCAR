
def str2bcd(d):
    if len(d)%2:
        d='0'+d
    out = bytearray(8)
    for i in range(0,len(d),2):
        t = d[i:i+2]
        out[int(i/2)+8-int(len(d)/2)] = (int(t[0])<<4)+int(t[1])
    return out