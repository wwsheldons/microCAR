##sys status
g=0
m=0
N_lock = 12
ws=[0]*N_lock
ls = [0]*N_lock

gnss_dat_OK = 0

#admin_phone = '13783601525'
#admin_phone = '13343839163'
set_phone = []

lock_status=[0]*N_lock
lose_lock = [10]*N_lock

flag_10ms = False
flag_1s = 0
flag_report = False
report_tick = 10
num_len = 11

check_rfid_time = 0


debug = 1

def debug_print(mess):
    if debug:
        print(mess)



        