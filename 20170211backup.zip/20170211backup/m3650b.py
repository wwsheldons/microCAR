import pyb
import GL

def rfid_init():
    GL.rfid_port = pyb.UART(3,9600,timeout=10,read_buf_len=12)
def get_id():
    if GL.rfid_port.any() == 12:
        GL.rfid_port.deinit()
        tmp = GL.rfid_port.read(12)
        #GL.debug_print('card data is {}'.format(tmp))
        #print('card data is {}'.format(tmp))
        ic_id = ''.join( [ '{:02X}'.format(x) for x in tmp[7:11] ] ).strip()
        rfid_init()
        return ic_id
        