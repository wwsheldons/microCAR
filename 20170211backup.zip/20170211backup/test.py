from implement import Implement_protocol
from gu906 import gprs_main
import select
import pyb
import GL
import gc
from utime import ticks_ms,ticks_diff
from wdt import wdog
from lcd12864 import lcd_main
from beep import alarm

from tja1040 import lock_main
from n303 import gnss_main
from storage import storage_main


def tick3(timer):
    if GL.rfid_port.any() == 12:
        GL.check_rfid_time = 1
    timer.deinit()


def start_check_rfid(n=20):
    
    #n_us < 1073741823
    #n_us =       1000*n
    tim3 = pyb.Timer(3)
    tim3.init(prescaler=84, period=1000*n)
    tim3.callback(tick3)


def main():
    
    GL.dog = wdog()
    
    gc.enable()
    sys = Implement_protocol()
    sys.self_check()
    #lock_main['lp_ons']()
    

    start_5s = ticks_ms()
    start_1s = ticks_ms()
    start_3min = ticks_ms()
    gprs_main['conect']()
    poll = select.poll()
    poll.register(GL.rfid_port, select.POLLIN)
    poll.register(GL.gprs_port, select.POLLIN)
    poll.register(GL.gnss_port, select.POLLIN)

    start_check_rfid()
    GL.dog.start(65535)
    while True:
        events = poll.poll()
        for file in events:
            if file[0] == GL.rfid_port and not GL.updating:
                GL.check_rfid_time = 0
                gc.collect()
                sys.handle_rfid()
                gc.collect()
                GL.dog.feed()
            
            if file[0] == GL.gprs_port and not GL.check_rfid_time:
                gc.collect()
                sys.handle_gprs()
                gc.collect()
                GL.dog.feed()
            

            if file[0] == GL.gnss_port and not GL.updating and not GL.check_rfid_time:
                tmp = GL.gnss_port.readline()
                #GL.debug_print(tmp)
                GL.gnss_dat_OK = gnss_main['update_buf'](tmp)
                gc.collect()
                GL.dog.feed()
            
            if ticks_diff(start_1s, ticks_ms()) > 1000 and not GL.updating and not GL.check_rfid_time:#1s
                #GL.debug_print('lock_main['checks']() is coming1111111111111111111111111')
                #sys.handle_control_cover()
                gc.collect()
                
                GL.lock_status = [1]*12
                
                
                lock_main['checks']()
                sys.handle_lock_cover()
                start_1s = ticks_ms()
                gc.collect()
                GL.dog.feed()
            if ticks_diff(start_5s, ticks_ms()) > 1000*GL.report_tick-3000 and not GL.updating and not GL.check_rfid_time:#5s
                GL.debug_print('update_sys_status() time is {}'.format(GL.report_tick))
                gc.collect()
                sys.update_sys_status()
                
                sys.handle_lock_cover()
                gprs_main['1003']()
                GL.dog.feed()
                if GL.m:
                    
                    ######swipe record
                    try:
                        n,s_rec = storage_main['g_sw_record']()
                        for i in range(n):
                            gprs_main['record'](0x1000,s_rec[i])
                            GL.dog.feed()
                        storage_main['c_sw_record']()
                    except:
                        pass
                    ######sms record
                    try:
                        n,sms_rec = storage_main['g_sms_record']()
                        for i in range(n):
                            gprs_main['record'](0x1000,sms_rec[i])
                            GL.dog.feed()
                        storage_main['c_sms_record']()
                    except:
                        pass
                    ######pos record
                    n_pos_record = storage_main['g_pos_record']()
                    if n_pos_record > 0:
                        if n_pos_record > 3:
                            d1 = n_pos_record-3
                        else:
                            d1 = 1
                        for i in range(d1,n_pos_record+1):
                            tmp = storage_main['g_pos_record'](i)
                            if isinstance(tmp,int):
                                continue
                            if len(tmp) >= 12+62:
                                #s= ticks_ms()
                                gprs_main['record'](0x1003,tmp)
                                #print('1003 send time is {}'.format(ticks_diff(s,ticks_ms())))
                                GL.dog.feed()
                            storage_main['c_pos_record'](i)
                            GL.dog.feed()
                        else:
                            print(i,tmp)
                else:
                    while not GL.gnss_dat_OK:
                        tmp = GL.gnss_port.readline()
                        gnss_main['update_buf'](tmp)
                        GL.dog.feed()
                    if GL.speed_times < 2 and GL.gnss_buf[0:1] == b'1':
                    #if GL.gnss_buf[0:1] == b'1':
                        gc.collect()
                        lock_main['update_ls']()
                        lss = bytearray(GL.lock_status)
                        storage_main['m_pos_record'](lss+GL.gnss_buf)
                    #gprs_main['conect']()
                    GL.dog.feed()
                gc.collect()
                GL.dog.feed()
                start_5s = ticks_ms()
            if ticks_diff(start_3min, ticks_ms()) > 1000*60 and not GL.updating and not GL.check_rfid_time:
                gc.collect()
                gprs_main['1012']()
                GL.dog.feed()
                GL.send_9012 += 1
                if GL.send_9012 >= 3:
                    GL.send_9012 = 0
                    GL.m = 0
                    gprs_main['conect']()
                    GL.dog.feed()
                start_3min = ticks_ms()
                gc.collect()
                GL.dog.feed()
            '''
            try:
                if ticks_diff(GL.err1_start_time, ticks_ms()) > 1000*60:
                    lcd_main['update_e'](1,0)
            except:
                pass
            '''
            gc.collect()
            GL.dog.feed()
        GL.dog.feed()
if __name__ == '__main__':
    main()
