import pyb
import GL
import gc
import os
import utime
from storage import storage_gprs
from n303 import gnss_gprs
from aes128 import encrypt,decrypt

from tja1040 import lock_gprs
from frame import frame_gprs
from dd import get_key
from lcd12864 import update_err
from beep import alarm,beep_on

from str2bcd import str2bcd
'''
1348
2696
4976
2280
'''
delay_time = 10
rssi = 0
ber = 0
GL.cme2_times = 0
GL.band = 38400
GL.server_tx_buf = []
GL.server_rx_buf = []
GL.file_name = ''
GL.at = 0
len_of_key_index = 2
len_of_len_dat = 4
len_of_host_id = 11
recv_set_sms = 0
cmgf = 0
cmgs = 0
cstt = 0
cmgd = 0


def gprs_init():
    GL.gprs_port = pyb.UART(4, 115200, read_buf_len=1024)
    #GL.gprs_port = pyb.UART(6, 115200, read_buf_len=1000)
    GL.g_en = pyb.Pin(pyb.Pin.cpu.B4, pyb.Pin.OUT_PP)
    GL.g_en.low()
    send_at('AT')
    send_at('AT+CMGF=1')#TxtMode: english mode
    #send_at('AT+IPR={}'.format(GL.band))#TxtMode: english mode
    

def send_at(order):
    GL.debug_print('send order is {}'.format(order))
    GL.gprs_port.write('{}\r\n'.format(order))
    wait_reply()
def send_d(d):
    #GL.debug_print('send dat is {}'.format(d))
    if GL.gprs_port.any():
        recv_server_dats()
    if not isinstance(d,bytearray):
        GL.gprs_port.write(bytearray(d))
    if d == 0x1a:
        GL.gprs_port.writechar(0x1a)
    wait_reply()
    
    
def recv_d(opt = 'line'):
    gc.collect()
    if opt == 'line':
        return GL.gprs_port.readline()
    if opt == 'all':
        return GL.gprs_port.readall()
    return 0
def findStr(string, findCnt):
    subStr = b'~'
    listStr = string.split(subStr,findCnt)
    if len(listStr) <= findCnt:
        return -1
    return len(string)-len(listStr[-1])-len(subStr)

    


def produce_N(n):
    ll = []
    if n % 2 == 0:
        for i in range(int(n/2)):
            ll.extend([i*2+1])
        return ll
    return None
def recv_server_dats():
    if GL.updating:
        opt = 'line'
    else:
        opt = 'all'
    tmp = recv_d(opt)
    try:
        if len(tmp) < 500:
            #pass
            GL.debug_print('recv data from gprs is {}'.format(tmp))
    except:
        return 0
    if tmp == 0 or tmp == None:
        return 0
    if b'AT\r\n' in tmp and b'OK' in tmp:
        GL.at = 1
        GL.debug_print('GPRS module has started working')
        return 1
    
    if GL.at == 0 and b'AT' not in tmp:
        if GL.m ==0:
            if GL.band == 38400:
                GL.band = 115200
            elif GL.band == 115200:
                GL.band = 38400
            else:
                pass
            GL.gprs_port = pyb.UART(4, GL.band, read_buf_len=1000)
            GL.debug_print('gprs bandrate is changed to {}'.format(GL.band))
            pyb.delay(1000)
            send_at('AT')
            send_at('AT+CMGF=1')#TxtMode: english mode
    
    if b'AT+IPR={}\r\n'.format(GL.band) in tmp:
        GL.gprs_port = pyb.UART(4, GL.band, read_buf_len=1000)
        GL.debug_print('gprs bandrate is changed to {}'.format(GL.band))
        GL.at = 0
        send_at('AT')
        send_at('AT+CMGF=1')#TxtMode: english mode
    if b'AT+CNUM=?\r\n' in tmp:
        ind = tmp.index(b'AT+CNUM=?')
        if tmp[ind+13:ind+15] == b'OK':
            GL.no_phone_card = 0
        else:
            GL.no_phone_card = 1
            
    if b'AT+CSQ\r\n' in tmp and b'OK' in tmp:
        try:
            ind = tmp.index(b'CSQ:')
            if tmp[ind+5] == b' ':
                rssi = int(chr(tmp[ind+6]),10)
            elif tmp[ind+8] == b' ':
                ber = int(chr(tmp[ind+9]),10)
            else:
                rssi = int(tmp[ind+5:ind+7].decode(),10)
                ber = int(tmp[ind+8:ind+10].decode(),10)
        except:
            pass
        GL.debug_print('AT+CSQ respond {}'.format(tmp))
    if 0x7e in tmp:
        count_7e = tmp.count(b'~')
        if count_7e % 2 == 0:
            num = produce_N(count_7e)
            for i in range(len(num)):
                d = tmp[findStr(tmp,num[i]):findStr(tmp,num[i]+1)+1]
                if GL.server_tx_buf == d:
                    continue
                #GL.debug_print('recv data frame is {}'.format(tmp))
                try:
                    unpack_server_data(d)
                    if order_from_server() == '9004':
                        GL.debug_print('9004 recv data frame is {}'.format(d))
                except:
                    continue
                if order_from_server in handle_order_dict.keys():
                    GL.server_rx_buf = []
                else:
                    continue
    
    if b'+CME ERROR:' in tmp:
        if b'+CME ERROR: 2' in tmp:
            GL.cme2_times = GL.cme2_times+1
            if GL.cme2_times >3:
                GL.cme2_times = 0
                send_at('AT+CIPCLOSE=0')
        
        if b'+CME ERROR: 9' in tmp:
            GL.m = 0
            conect_()
    if b'+CMTI: "ME"' in tmp:
        ind = tmp.index(b'+CMTI: "ME"')
        n = int(chr(tmp[ind+12]))
        rec_sms(n)

    if b'AT+CMGR=' in tmp and b'REC ' in tmp and b'OK' in tmp:
        tmp = tmp.decode()
        try:
            ind = tmp.index('REC UNREAD')+16
        except:
            ind = tmp.index('REC READ')+14
        phone_num = tmp[ind:ind+11]
        
        try:
            ind_tn = tmp.index('#')
            ind_ok = tmp.index('OK')
            if phone_num == GL.admin_phone or phone_num in GL.set_phone:
                sms_context = tmp[ind_tn+1:ind_ok-4]
                del_sms()
                unpack_sms(phone_num,sms_context)
            else:
                #send_sms(phone_num,'your num is not in law')
                del_sms()
                print(-4) # phone num is not in law
        except:
            del_sms()
    if b'CONNECT OK' in tmp:
        GL.m = 1
    '''
    if b'SEND OK' in tmp:
        GL.m = 1
    '''
    
    if b'CLOSED' in tmp or b'SEND FAIL' in tmp:
        GL.m = 0
        send_at('AT+CIPCLOSE=0')
        
    '''
    if rssi > 0 and rssi<32 and GL.m==0:
        conect_()
    '''
    if b'+FTPGET: 1,' in tmp:
        GL.updating = 1
        ind1 = tmp.index(b'+FTPGET: 1,')+12
        ind2 = tmp[ind1:].index(b'\r\n')
        GL.file_size = int(tmp[ind1:ind2+ind1].decode(),10)
        GL.all_size = GL.file_size
        send_at('AT+FTPGET=2,{}'.format(GL.file_size))
        #send_at('AT+FSDWL="{}",{}'.format(GL.file_name,GL.file_size))
        #wait_reply()
    if b'+FTPGET: 2,' in tmp:
        #os.remove('/sd/'+GL.file_name)
        GL.updating = 2
    if GL.updating == 2 and b'+FTPGET' not in tmp:
        if GL.all_size == GL.file_size and tmp == b'\r\n':
            return 0
        if tmp == b'OK\r\n':
            GL.updating = 1
            return 0
        #GL.debug_print('GL.file_size is {} and len(tmp) is {}'.format(GL.file_size,len(tmp)))
        if GL.file_size > len(tmp):
            storage_gprs['write_line'](GL.file_name,'a',tmp,0)
            GL.file_size = GL.file_size - len(tmp)
            GL.debug_print('after storage GL.file_size is {}'.format(GL.file_size))
        else:
            if tmp[GL.file_size-2:GL.file_size] == b'\r\n':
                GL.file_size = GL.file_size - 2
            GL.debug_print('tmp[GL.file_size-2:GL.file_size] is {}'.format(tmp[GL.file_size-3:GL.file_size]))
            if b'#$%' in tmp[GL.file_size-3:GL.file_size]:
                GL.dwl_over = 1
            storage_gprs['write_line'](GL.file_name,'a',tmp[:GL.file_size],0)
            GL.updating = 1
            GL.all_size = GL.file_size = 0
            GL.debug_print('after storage GL.file_size is {}'.format(GL.file_size))
            wait_reply()
    if b'+FTPERR:' in tmp:
        send_1011('2')  #update fail
        
    if b'@@Ver:' in tmp and b'Build Time:' and GL.updating:
        send_1011('2')  #update fail
        
      #b'+FTPGET: 2, 0\r\n'
    if b'+FTPGET: 2, 0\r\n' in tmp:
        pyb.delay(2000)
        rec_tmp = recv_server_dats()
        GL.debug_print('recv_server_dats() return data is {}'.format(rec_tmp))
        if rec_tmp == 0:
            if GL.dwl_over ==1:
                GL.updating = 0
                GL.dwl_over = 0
                if GL.file_size == 0:
                    send_1011('1')  #update success
                    send_at('AT+IPR={}'.format(115200))
                    GL.gprs_port = pyb.UART(4, 115200, read_buf_len=1000)
                    pyb.delay(1000)
                    pyb.hard_reset()
                else:
                    send_1011('2')  #update fail
            else:
                send_1011('2')  #update fail
    GL.dog.feed()
    gc.collect()
    return 0


def wait_reply(timeout=0.5):
    start = utime.ticks_ms()
    while not GL.gprs_port.any():
        if utime.ticks_diff(start, utime.ticks_ms()) > 1000*timeout:
            break
        else:
            continue
    if recv_server_dats() == 0:
        return 1
def check_phone_card():
    send_at('AT+CNUM=?')
def check_csq():
    send_at('AT+CSQ')
def check_conect():
    send_at('AT+CIPSTART?')
def wait_set_sms():
    send_sms(GL.admin_phone,'waiting for init by ip, port and id')
    tmp_n = 0
    while not recv_set_sms:
        tmp_n += 1
        
        if tmp_n > 10:
            send_sms(GL.admin_phone,'waiting for init by ip, port and id')
            tmp_n = 0
            pyb.delay(500)
        beep_on()
        rec_sms()
    return 1
def rec_sms(num=1):
    send_at('AT+CMGR={}'.format(num))
def del_sms():
    send_at('AT+CMGD=1,4')#del all the sms
    return cmgd
def send_sms(phone_num,dat = 'hello world!'):
    send_at('AT+CMGS=\"+86{}\"'.format(phone_num))
    pyb.delay(20)
    send_d(dat)#sms contents
    send_d(0x1a)# send
    pyb.delay(50)
    del_sms()
    pyb.delay(50)
    

#def conect_(ip = "101.201.105.176",port = 5050,apn='',usr = '',passwd=''):
def conect_(apn='',usr = '',passwd=''):
    if apn != '' :
        send_at('AT+CSTT={},{},{}'.format(apn,usr,passwd))
        return GL.m
    send_at('AT+CSTT="CMNET","",""')
    send_at('AT+CGATT=1')
    send_at('AT+CIPSTART="TCP","{}",{}'.format(GL.ip,GL.port))
    wait_reply()
    GL.dog.feed()
    return GL.m
def send_dats(d,order=0):
    if order != 0:
        GL.debug_print('the order will be send is {}'.format(hex(order)[2:]))
    #GL.debug_print('the dat will be send is{}'.format(d))
    if GL.m == 0:
        conect_()
    wait_reply()
    send_at('AT+CIPSEND={},1'.format(len(d)))
    #send_at('AT+CIPSEND={}'.format(len(d)))#bin type
    send_d(d)
    GL.dog.feed()
    gc.collect()
    GL.gnss_dat_OK = 0
    return 1



def prodece_key_index():
    return ('{:0>2}'.format(os.urandom(1)[0]%99)).encode()
def pack_server_data(order,dat,opt = 0x01):
    if not isinstance(dat,bytes):
        dat = bytes(dat)
    tmp_key_index = prodece_key_index()
    tmp_order = hex(order)[2:].encode() # 4 bytes
    tmp_data = tmp_order + dat
    if opt & 0x01:
        gc.collect()
        data = bytes(encrypt(tmp_data, get_key(int(str(tmp_key_index,'utf-8')))))
        gc.collect()
    else:
        data = tmp_data
    #len_dat = ('%04d'%(len(data))).encode()  # 4 bytes
    len_dat = ('{:0>4}'.format(len(data))).encode()
    tx_buf = len_dat+tmp_key_index+data
    crc_ = frame_gprs['_crc32'](tx_buf)
    tx_buf = tx_buf + crc_
    tx_buf = frame_gprs['mean'](tx_buf)
    GL.server_tx_buf = b'~'+ tx_buf + b'~'
    GL.gnss_dat_OK = 0
    return GL.server_tx_buf
def sms_operate_lock(order,num):
    if 'open' in order:
        order = 'open'
    if 'close' in order:
        order = 'close'
    lock_gprs[order+'s']()
    while not GL.gnss_dat_OK:
        tmp = GL.gnss_port.readline()
        gnss_gprs['update_buf'](tmp)
    storage_gprs['m_sms'](bytearray([int(hex(i<<4),16) + j for i,j in zip(GL.ws,GL.ls)])+GL.gnss_buf+str2bcd(num))
    send_sms(num,dat='{} locks finished'.format(order))
    return 1
def unpack_sms(num,context,opt = 0x01):
    GL.debug_print('num is {} and context is {}'.format(num,context))
    if 'password' in context:
        ind_password = context.index('password:')
        sms_password = context[ind_password+9:ind_password+14]
        storage_gprs['m_pwd'](sms_password)
    if 'ip' in context and 'id' in context and 'port' in context:
        ind_ip = context.index('ip:')
        ind_ip_end = context[ind_ip+1:].index('#')
        ip = context[ind_ip+3:ind_ip_end+ind_ip+1]
        storage_gprs['m_ip'](ip)
        ind_port = context.index('port:')
        port = context[ind_port+5:ind_port+9]
        storage_gprs['m_port'](port)
        ind_id = context.index('id:')
        con_id = context[ind_id+3:ind_id+14]
        storage_gprs['m_id'](con_id)
        send_sms(num,dat='ip port and id set OK')
        storage_gprs['m_using_times']()
        recv_set_sms = 1
    if 'admin phone' in context:
        ind = context.index(':')
        ph1 = context[ind+1:ind+12]
        if ',' in context:
            ind2 = context.index(',')
            ph2 = context[ind2+1:ind2+12]
            GL.set_phone = [ph1,ph2]
            storage_gprs['m_ap'](ph1+ph2)
        else:
            GL.set_phone = [ph1]
            storage_gprs['m_ap'](ph1)
        send_sms(num,dat='admin phone set OK')
        return 1
    if 'ic' in context:
        ind = context.index('ic:')
        order = context[ind+3:]
        return sms_operate_lock(order,num)
    if 'power' in context:
        ind = context.index('power')+6
        order = context[ind:]
        if order == 'restart':
            send_sms(num,dat='the board will be restart after 2 seconds')
            pyb.delay(2000)
            pyb.hard_reset()
    if 'lock' in context:
        ind = context.index('lock:')+5
        order = context[ind:]
        if order == 'on':
            GL.lock_status = [1]*12
            storage_gprs['m_ls'](0)
            lock_gprs['lp_ons']()
            send_sms(num,dat='locks have power on')
            return 1
    pyb.delay(2000)
    pyb.hard_reset()
    return 1
def unpack_server_data(dat,opt = 0x01):
    '''
    opt = 0bxxxx xxxx
    the 0th bit: ase128 coding---1    not coding---0
    the 1-7th bit: reserve
    '''
    tmp = dat
    if 0x7d in tmp:
        tmp = frame_gprs['remean'](tmp)
    if tmp[0] == 126 and tmp[-1] == 126:
        tmp = tmp[1:-1]
        tmp_len_dat = int(tmp[:4].decode())
        tmp_key = get_key(int(tmp[4:6].decode()))
        tmp_frame = tmp[:-4]
        tmp_dat = tmp[6:-4]
        tmpcrc32 = tmp[-4:]
        if frame_gprs['_crc32'](tmp_frame) == tmpcrc32:
            pass
        else:
            GL.debug_print ('crc32 error')
        length_frame = tmp_len_dat
        key = tmp_key
        if (opt & 0x01):
            
            d = bytes(decrypt([i for i in tmp_dat],tmp_key,tmp_len_dat))
            gc.collect()
        else:
            d = tmp_dat
        GL.server_rx_buf = d
        GL.rx_dat = get_rx_dat()
        order = order_from_server()
        GL.rec_order = order
        if order in handle_order_dict.keys():
            GL.debug_print('order from server {}'.format(order))
            handle_order_dict[order]()
            GL.m = 1
            GL.cme2_times = 0
        #return GL.server_rx_buf
    else:
        GL.debug_print('the data is not a frame')
        return None

def method1xxx(order,*tupleArg):#bytes(i) elif isinstance(i,bytearray)
    dat = b''.join([i.encode() if isinstance(i,str)  else i for i in tupleArg])
    gc.collect()
    try:
        GL.debug_print('dat before encrypt is {}'.format(dat))
    except:
        pass
    return pack_server_data(order,dat)

    

def get_location_gu():
    send_at('AT+ENBR')

def send_record(order,dat):
    dat = GL.host_id + dat
    d = method1xxx(order,dat)
    send_dats(d,order)
    return 1
def handle_900x(order,ic_id=''):
    lock_gprs['update_ls']()
    lss = bytes(GL.lock_status)
    while not GL.gnss_dat_OK:
        tmp = GL.gnss_port.readline()
        gnss_gprs['update_buf'](tmp)
    d = method1xxx(order,GL.host_id,lss,bytes(GL.gnss_buf),ic_id)
    
    send_dats(d,order)
    return 1
def send_1003():
    return handle_9003()
def send_1011(info):
    GL.updating = 0
    d = method1xxx(0x1011,GL.host_id,info)
    send_dats(d,0x1011)
    return 1
def send_1012():
    return handle_900x(0x1012)
def send_1000(ic_id):
    return handle_900x(0x1000,ic_id)
def handle_9000():
    GL.debug_print('9000 rx_dat {}'.format(GL.rx_dat))
    for i in range(GL.N_lock):
        #print('GL.rx_dat[i] is {}'.format(GL.rx_dat[i]))
        if GL.rx_dat[i] in [48,'0',b'0']:
            pass
        if GL.rx_dat[i] in [49,'1',b'1']:
            lock_gprs['open'](i)
        if GL.rx_dat[i] in [50,'2',b'2']:
            lock_gprs['close'](i)
        if GL.rx_dat[i] in [51,'3',b'3']:
            update_err(1)
        if GL.rx_dat[i] in [52,'4',b'4']:
            update_err(2)
        if GL.rx_dat[i] in [53,'5',b'5']:
            update_err(3)
    if b'3' in GL.rx_dat or b'4' in GL.rx_dat or b'5' in GL.rx_dat:
        alarm(3)
    return handle_900x(0x1001)
def handle_9002():
    return handle_900x(0x1002)
def handle_9003():
    return handle_900x(0x1003)
def handle_9004():
    GL.debug_print('9004 rx_dat {}'.format(GL.rx_dat))
    storage_gprs['m_gas_info'](GL.rx_dat)
    tmp1 = storage_gprs['g_gas_id']()
    storage_gprs['load_em']()

    d = method1xxx(0x1004,GL.host_id,tmp1)
    send_dats(d,0x1004)
    gc.collect()
    return 1
def handle_9005():
    gc.collect()
    n,gas_info = storage_gprs['g_gas_info']()
    GL.debug_print('gas_info is {}'.format(gas_info))
    mm,mn = divmod(n,3)
    totle = mm +(not(not mn))
    for i in range(totle):
        if i<totle-1:
            d = method1xxx(0x1005,GL.host_id,str(3),''.join([i for i in gas_info[i*3:i*3+3]]))
            send_dats(d,0x1005)
        if i == totle-1:
            d = method1xxx(0x1005,GL.host_id,str(mn),''.join([i for i in gas_info[mm*3:]]))
            send_dats(d,0x1005)
        #yield(1000)
        pyb.delay(500)
    
    '''
    for i in range(n):
        d = method1xxx(0x1005,GL.host_id,str(1),gas_info[i])
        send_dats(d,0x1005)
        yield(500)
        '''
    gc.collect()
    return 1
def handle_9006():
    n,gas_info = storage_gprs['g_gas_info']()
    storage_gprs['m_gas_info']([])
    d = method1xxx(0x1006,GL.host_id,str(n))
    send_dats(d,0x1006)
    return 1
def send_1007():
    d = method1xxx(0x1007,GL.host_id,GL.emergency_open_card+'{:0>2}'.format(GL.emergency_open_card_times))
    send_dats(d,0x1007)
    return 1
def handle_9007():
    GL.debug_print('9007 data is {}'.format(GL.rx_dat))
    if int(GL.rx_dat[-2:]) == 0:
        storage_gprs['m_emergency_c_card'](GL.rx_dat[:-2].decode())
        d = method1xxx(0x1007,GL.host_id,GL.emergency_close_card+'{:0>2}'.format(0))
    if int(GL.rx_dat[-2:]) > 0:
        storage_gprs['m_emergency_card'](GL.rx_dat.decode())
        d = method1xxx(0x1007,GL.host_id,GL.emergency_open_card+'{:0>2}'.format(GL.emergency_open_card_times))
    storage_gprs['load_em']()
    
    send_dats(d,0x1007)
    return 1
def handle_9008():
    GL.debug_print('9008 tx_buf is {}'.format(GL.rx_dat))
    if GL.rx_dat in [b'1',49]:
        storage_gprs['m_ls'](0)
        lock_gprs['lp_ons']()
    elif GL.rx_dat in [b'2',50]:
        lock_gprs['lp_offs']()
    else:
        return 0
    d = method1xxx(0x1008,GL.host_id,GL.rx_dat)
    send_dats(d,0x1008)
    
    return 1
def handle_9009():
    GL.debug_print('9009 tx_buf is {}'.format(GL.rx_dat))
    if GL.rx_dat in [b'1',49]:
        pyb.delay(1000)
        pyb.hard_reset()
def handle_9010():
    GL.debug_print('9010 rx_dat {}'.format(GL.rx_dat))
    GL.report_tick = int(GL.rx_dat.decode())
    d = method1xxx(0x1010,GL.host_id,'{:0>4}'.format(GL.report_tick))
    send_dats(d,0x1010)
    return 1
def handle_9011():
    GL.debug_print('9011 rx_dat {}'.format(GL.rx_dat))
    tmp = GL.rx_dat.decode()
    pyb.delay(5000)
    wait_reply()
    GL.updating = 1
    send_at('AT+IPR={}'.format(GL.band))

    ind = tmp.split('#')
    addr = ind[0]
    usr = ind[1]
    passwd = ind[2]
    GL.file_name = ind[3]
    send_at('AT+FTPSERV="{}"'.format(addr))
    send_at('AT+FTPGETNAME="{}"'.format(GL.file_name))
    send_at('AT+FTPUN="{}"'.format(usr))
    send_at('AT+FTPPW="{}"'.format(passwd))
    send_at('AT+FTPGET=1')
    
def handle_9012():
    GL.send_9012 -= 1
    if GL.send_9012 < 0:
        GL.send_9012 = 0
def get_rx_id():
    return GL.server_rx_buf[4:4+11].decode()

def get_rx_dat():
    frame_len_dict = {'9000':23,'9010':15,'9007':21,'9008':12,'9009':12,'9004':13+59,'9005':11,
                      '9006':11,'9002':11,'9003':11,'9005':11,'9006':11,'9011':12,'9012':11}
    start = 4+11
    order = order_from_server()
    if order in ['9002','9003','9005','9006','9012']:
        return 1
    if order in ['9000','9010','9007','9008','9009']:
        len_of_frame = frame_len_dict[order]-11
    if order == '9004':
        n = int(chr(GL.server_rx_buf[4+11+1]))
        len_of_frame = 13+59*n-11
    if order == '9011':
        n = GL.server_rx_buf.index(b'y')
        len_of_frame = n+1
    if order not in frame_len_dict.keys():
        GL.debug_print(order)
        GL.debug_print('wrong order from server')
        return None
    return GL.server_rx_buf[start:len_of_frame+start]

def order_from_server():
    return GL.server_rx_buf[0:4].decode()

handle_order_dict = {'9000':handle_9000,'9002':handle_9002,
                     '9010':handle_9010,'9004':handle_9004,
                     '9005':handle_9005,'9006':handle_9006,
                     '9007':handle_9007,'9008':handle_9008,
                     '9009':handle_9009,'9011':handle_9011,
                     '9012':handle_9012}
gprs_sys = {'init':gprs_init, 'unpack':unpack_server_data, 'recv':recv_server_dats, 'pack':pack_server_data,
'1000':send_1000,'1003':send_1003,'1007':send_1007,'recsms':rec_sms,'wait':wait_set_sms,'csq':check_csq,
'phone_card':check_phone_card}

gprs_main = {'1003':send_1003,'conect':conect_,'1012':send_1012,'record':send_record}