from tja1040 import lock_gnss
import pyb
import GL
from frame import checksum_gps
from lcd12864 import clc_a

antenna_status_dict = {'SHORT':0,'OPEN':1,'OK':2}
antenna_status = antenna_status_dict['OPEN']
GL.gga_finish = 0
GL.rmc_finish = 0
GL.pre_time = ''

battery_voltage = pyb.ADC(pyb.Pin.cpu.B1)
vcc_voltage = pyb.ADC(pyb.Pin.cpu.B0)
def clear_gnss_buf():
    GL.gnss_buf = bytearray('216-06-0320:08:0023447.9072111335.68360123000000.00001111*****')
def gnss_init():
    GL.gga_finish = 0
    GL.rmc_finish = 0
    GL.speed = 0
    GL.speed_times = 0
    GL.gnss_port = pyb.UART(2,9600,timeout=10,read_buf_len=64)
    GL.gnss_reset_pin = pyb.Pin(pyb.Pin.cpu.B4, pyb.Pin.OUT_PP)
    GL.gnss_reset_pin.low()
    clear_gnss_buf()

def reset_gnss():
    GL.gnss_reset_pin.high()
    pyb.delay(50)
    GL.gnss_reset_pin.low()

def unpack_gga(datlist):
    #GL.debug_print('this is GNGGA')
    t17_dict = {b'N':b'1',b'S':b'2'}
    t27_dict = {b'E':b'1',b'W':b'2'}
    if datlist[6] == b'0':
        GL.debug_print('the gnss is invalid')
        return 0
    try:
        if datlist[6] == b'':#####GPS status
            return 0
        GL.gnss_buf[0:1] = datlist[6]
        GL.gnss_buf[9:11] = datlist[1][0:2]     #####hh
        GL.gnss_buf[11:12] = b':'
        GL.gnss_buf[12:14] = datlist[1][2:4]     #####mm
        GL.gnss_buf[14:15] = b':'
        GL.gnss_buf[15:17] = datlist[1][4:6]     #####ss
        GL.gnss_buf[17:18] = t17_dict[datlist[3]]
        GL.gnss_buf[18:27] = datlist[2][:9]          #####longitude
        GL.gnss_buf[27:28] = t27_dict[datlist[5]]
        GL.gnss_buf[28:38] = datlist[4][:10]          #####latitude
        GL.gnss_buf[51:53] = datlist[7]          #####num of satllites

        sea_level = int(float(datlist[9].decode()))
        #GL.gnss_buf[38:42] = ('%04d'%sea_level).encode()        #####sea level
        GL.gnss_buf[38:42] = ('{:0>4}'.format(sea_level)).encode()        #####sea level
        #GL.debug_print('unpack GNGGA is over')
        return 1
    except:
        return 0
def unpack_rmc(datlist):
    if datlist[12][0:1] == b'N':
        GL.debug_print('the gnss is invalid')
        GL.gnss_buf[0:1] = b'2'
        return 0
    if datlist[12][0:1] == b'A':
        GL.gnss_buf[0:1] = b'1'
    try:
        GL.gnss_buf[1:3] = datlist[9][4:6]       ######yy
        GL.gnss_buf[3:4] = b'-'
        GL.gnss_buf[4:6] = datlist[9][2:4]       ######mm
        GL.gnss_buf[6:7] = b'-'
        GL.gnss_buf[7:9] = datlist[9][0:2]       ######dd

        GL.speed = int(1.852*float(datlist[7].decode()))######speed and km/m
        if GL.speed < 1:
            GL.speed_times += 1
        if GL.speed > 1:
            GL.speed_times = 0
        if GL.speed > 30:
            clc_a()

        #GL.gnss_buf[42:45] = ('%03d'%speed).encode() #3 bytes
        GL.gnss_buf[42:45] = ('{:>03}'.format(GL.speed)).encode() #3 bytes
        yaw = '%06.2f'%float(datlist[8].decode())
        #yaw = '{:^06.2}'.format(datlist[8].decode())  # 6bytes total and 2 bytes decimal 3 bytes integer
        GL.gnss_buf[45:51] = yaw.encode()     ######yaw
        #GL.debug_print('unpack GNRMC is over')
        return 1
    except:
        return 0
def unpack_txt(datlist):
    try:
        tmp = datlist[4].split(b' ')
    except:
        return None
    if tmp[1][0:2] == b'OK':
        GL.debug_print('the antenna is OK')
        antenna_status = antenna_status_dict['OK']
        return 1
    elif tmp[1][0:4] == b'OPEN':
        GL.debug_print('the antenna is OPEN')
        antenna_status = antenna_status_dict['OPEN']
        return 1
    elif tmp[1][0:4] == b'SHORT':
        GL.debug_print('the antenna is SHORT')
        antenna_status = antenna_status_dict['SHORT']
        return 1
    else:
        GL.debug_print('the GNTXT data frame is wrong')
        return None
def update_gnss_buf(data):
    #GL.debug_print('gnss rec data is ()'.format(data))
    try:
        if data[0:1] != b'$' or b'*' not in data:# 36--$    42---*
            GL.debug_print('data type is wrong  {}'.format(data))
            
            return None
        checksum = checksum_gps(data)
        
        try:
            rec_crc = int(data[data.index(b'*')+1:data.index(b'*')+3].decode(),16)
        except:
            GL.debug_print('data type is wrong')
            return None
        #data = str(data,'utf-8')
        #GL.debug_print('checksum,rec_crc {}'.format(checksum,rec_crc))
        if GL.control_cover.read() > 3900:
            GL.gnss_buf[54:55] = b'2'
        if GL.control_cover.read() < 300:
            GL.gnss_buf[54:55] = b'1'
        if vcc_voltage.read() < 1699: #14V
            #bat_en.value(1)
            GL.gnss_buf[56:57] = b'0'
            lock_gnss['lp_off']()
            #gprs.send_1003()
        else:
            GL.gnss_buf[56:57] = b'1'
        
        if vcc_voltage.read() > 2243: #19V
            GL.gnss_buf[56:57] = b'1'
            if GL.gnss_buf[56:57] == b'0':
                lock_gnss['lp_ons']()
                GL.lock_status = [1]*12
                lock_gnss['checks']()
        else:
            GL.gnss_buf[56:57] == b'0'
        if battery_voltage.read() < 1216: #10V
            GL.gnss_buf[55:56] = b'0'
            if GL.gnss_buf[56:57] == b'0':
                lock_gnss['lp_offs']()
        if battery_voltage.read() > 1316:
            GL.gnss_buf[55:56] = b'1'

        
        if checksum != rec_crc:
            GL.debug_print ('gnss crc error checksum is {} data is {} '.format(hex(checksum),data))

        datlist = data.split(b',')  #,---44
        if datlist[0] == b"$GNGGA" and len(datlist) == 15:
             unpack_gga(datlist)
             GL.gga_finish = 1
        elif datlist[0] == b"$GNRMC" and len(datlist) == 13:
             unpack_rmc(datlist)
             GL.rmc_finish = 1
        elif datlist[0] == b"$GNTXT" and len(datlist) == 4:
            txt_finish = unpack_txt(datlist)
        else:
            return None
        if GL.gnss_buf[0] == 49:
            GL.g = 1
        elif GL.gnss_buf[0] == 50:
            GL.g = 0
        else:
            GL.gga_finish = 0
            GL.rmc_finish = 0
            GL.gnss_dat_OK = 0
            return 0
        if GL.gga_finish and GL.rmc_finish:
            GL.gga_finish = 0
            GL.rmc_finish = 0
            GL.debug_print('the whole unpack successfully')
            if len(GL.gnss_buf) != 62:
                clear_gnss_buf()
                GL.gnss_dat_OK = 0
                return 0
            GL.gnss_dat_OK = 1
            GL.debug_print(GL.gnss_buf)
            return GL.gnss_buf
        else:
            return 0
    except:
        return 0


def gnss_position():
    
    return float(bytes(GL.gnss_buf[18:27]).decode()),float(bytes(GL.gnss_buf[28:38]).decode())

def gnss_date():
    return GL.gnss_buf[1:9]

def gnss_time():
    return GL.gnss_buf[9:17]

gnss_sys = {'init':gnss_init,'get_pos':gnss_position,'update_buf':update_gnss_buf}
gnss_gprs = {'update_buf':update_gnss_buf}
gnss_main = gnss_gprs