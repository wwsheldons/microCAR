import pyb
import GL
import time
def beep_init():
    GL.beep_port=pyb.Pin(pyb.Pin.cpu.A8, pyb.Pin.OUT_PP)
    GL.beep_port.low()

def tick5(timer):
    GL.beep_port.low()
    timer.deinit()
def beep_on(utime=500):
    GL.beep_port.high()
    #n_us < 1073741823
    #n_us =       1000*n
    tim5 = pyb.Timer(5)
    tim5.init(prescaler=84, period=1000*utime)
    tim5.callback(tick5)

def alarm(n=3):
    for i in range(n):
        GL.beep_port.high()
        time.sleep_ms(100)
        GL.beep_port.low()
        time.sleep_ms(100)
'''
def beep_on(utime=500,f=2000):
    t1 = pyb.Timer(1)
    t1.init(freq=f, mode=pyb.Timer.CENTER)
    t1.channel(1, pyb.Timer.PWM, pin=pyb.Pin.cpu.A8, pulse_width=(t1.period() + 1) // 4)
    pyb.delay(utime)
    t1.deinit()
def alarm(n=2):
    for i in range(n):
        beep_on(100)
        time.sleep_ms(100)

def beep_on(n=500):
    beep_port.value(1)
    pyb.delay(n)
    beep_port.value(0)
def alarm(n=2):
    for i in range(n):
        beep_port.high()
        time.sleep_ms(100)
        beep_port.low()
        time.sleep_ms(100)
'''