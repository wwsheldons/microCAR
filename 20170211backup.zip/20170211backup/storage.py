import pyb
import os
import gc
import GL
_gas_info_split = [6,8,8,2,9,10,4,12]
gas_info_split = [sum(_gas_info_split[:i+1])+i for i in range(len(_gas_info_split)-1)]


path = '/sd/log/'
pos_path = path+'pos_record'
prnfn = pos_path+'/num.txt'
usfn = path+'using_times.txt'
ipfn = path+'ip.txt'
portfn = path + 'port.txt'
apnfn = path + 'apn.txt'
idfn = path + 'id.txt'
pwdfn = path + 'passwd.txt'
apfn = path+'admin_phone.txt'
eocfn = path+'emergency_open_card.txt'
eccfn = path+'emergency_close_card.txt'
gifn = path+'gas_info.txt'
srfn = path+'swipe_record.txt'
smsfn = path+'sms_record.txt'
pdrfn = path+'power_down_record.txt'
lorfn = path+'lock_open_record.txt'
corfn = path+'control_open_record.txt'
posfn = path+'pos_record.txt'
lsfn = path+'lock_status.txt'



def load_sys_variable():
    GL.host_id = get_id()
    GL.ip = get_ip()
    GL.port = get_port()
    GL.gas_num = []
    GL.ic_open = []
    GL.ic_close = []
    GL.ic_using_times = []
    GL.gas_latitude = []
    GL.gas_longitude = []
    GL.distance = []
    GL.oprerate_lock_status = []
    load_emergency_variable()
def load_emergency_variable():
    GL.gas_num = []
    GL.ic_open  = []
    GL.ic_close = []
    GL.ic_using_times = []
    GL.gas_latitude = []
    GL.gas_longitude = []
    GL.distance = []
    GL.oprerate_lock_status = []
    GL.emergency_close_card = []
    GL.emergency_open_card = []
    try:
        n,GL.set_phone = get_adimin_phone()
    except:
        pass
    try:
        GL.emergency_open_card,GL.emergency_open_card_times = get_emergency_open_card()
        GL.emergency_close_card = get_emergency_close_card()
    except:
        pass
    try:
        n, gas_info = get_gas_info()
        GL.n_gas = n
        for i in range(n):
            GL.gas_num.extend([gas_info[i][:6]])
            GL.ic_open.extend([gas_info[i][6:14]])
            GL.ic_close.extend([gas_info[i][14:22]])
            GL.ic_using_times.extend([int(gas_info[i][22:24])])
            GL.gas_latitude.extend([float(gas_info[i][24:33])])
            GL.gas_longitude.extend([float(gas_info[i][33:43])])
            GL.distance.extend([int(gas_info[i][43:47])])
            GL.oprerate_lock_status.extend([[int(j) for j in gas_info[i][47:]]])
    except:
        pass
def del_one_group_emergency_variable(n):
    del GL.gas_num[n]
    del GL.ic_open[n]
    del GL.ic_close[n]
    del GL.ic_using_times[n]
    del GL.gas_latitude[n]
    del GL.gas_longitude[n]
    del GL.distance[n]
    del GL.oprerate_lock_status[n]
    GL.n_gas -= 1
def save_emergency_variable():
    tmp = []
    for i in range(GL.n_gas):
        print(GL.gas_num,GL.n_gas)
        try:
            print(GL.oprerate_lock_status[i])
            tmp.extend([GL.gas_num[i]+GL.ic_open[i]+GL.ic_close[i]+str(GL.ic_using_times[i])+
                '{:0>9}'.format(GL.gas_latitude[i])+'{:0>10}'.format(GL.gas_longitude[i])+
                '{:0>4}'.format(GL.distance[i])+''.join([str(j) for j in GL.oprerate_lock_status[i]])])
            '''
            tmp.extend([GL.gas_num[i]+GL.ic_open[i]+GL.ic_close[i]+str(GL.ic_using_times[i])+
                '%09.4f'%GL.gas_latitude[i]+'%10.4f'%GL.gas_longitude[i]+'{:0>4}'.format(GL.distance[i])+
                ''.join([str(j) for j in GL.oprerate_lock_status[i]])])
            '''
        except:
            return 0
    return modify_gas_info(tmp)
def prepare_dir():
    all_file = os.listdir('/sd')
    if 'log' in all_file:
        log_file = os.listdir('/sd/log')
        for i in log_file:
            os.remove('/sd/log/'+i)
        os.rmdir('log')
    
    os.mkdir('/sd/log')
    os.mkdir('/sd/log/pos_record')
    gc.collect()
def prepare_file():
    modify_using_times(0)
    modify_ip('')
    modify_port(0)
    modify_ls(0)
    modify_id('')
    modify_pwd('')
    modify_adimin_phone('')
    modify_emergency_open_card('')
    modify_emergency_close_card('')
    modify_gas_info('')
    modify_swipe_record('')
    modify_sms_record('')
    modify_power_down_record('')
    modify_lock_open_record('')
    modify_control_open_record('')
    modify_pos_record('')
    gc.collect()
def get_info(filename,opt):
    '''
    opt = 'all     read all
    opt = 'line'   realine
    '''
    lines = 0
    out = []
    try:
        with open(filename, 'rb') as f:
            if opt == 'line':
                tmp = f.readline()
                f.close()
                pyb.sync()
                if tmp == b'':
                    return '0'
                if b'\r\n' in tmp:
                    tmp = tmp[:-2]
                gc.collect()
                return tmp.decode()

            elif opt == 'all':
                for eachline in f:
                    lines += 1
                    if  b'\r\n' in eachline:
                        eachline = eachline[:-2]
                    out.append(eachline.decode())
                gc.collect()
                return lines,out
            else:
                print('wrong option')
                gc.collect()
                return None
    except OSError as error:
        print("Error: can not write to SD card. %s" % error)
        gc.collect()
        return 0
def write_file(filename,dat):
    all_file = os.listdir('/sd')
    fn,suffix = filename.split('.')
    if fn+'_old.'+suffix in all_file:
        os.remove(fn+'_old.'+suffix)
    if filename in all_file:
        os.rename(filename,fn+'_old.'+suffix)
    with open(filename, 'w') as f:
        f.write(dat)
        f.close()
        pyb.sync()
    gc.collect()
    return 1
def write_line_to_file(filename,mode,dat,new_line):
    try:
        with open(filename, mode) as f:
            f.write(dat)
            if new_line:
                f.write('\r\n')
            f.close()
            pyb.sync()
            pyb.delay(50)
            gc.collect()
            return 1
    except OSError as error:
        print("Error: can not write to SD card. %s" % error)
        gc.collect()
        return None

def modify_info(filename,dat,opt,new_line = 0):
    '''
    opt = 'add'      add to
    opt = 'rewrite'  rewrite
    '''
    if isinstance(dat,bytearray):
        pass
    elif isinstance(dat,str):
        pass
    elif isinstance(dat,int):
        dat = str(dat)
    elif dat == None:
        pass
    else:
        print('{} wrong data type'.format(filename))
    #print('dat is {}'.format(dat))
    if opt == 'rewrite':
        mode = 'wb'
    elif opt == 'add':
        mode = 'a'
    else:
        #print('wrong option')
        return None
    write_line_to_file(filename,mode,dat,new_line)
    gc.collect()
def modify_infos(filename,dat,order = 'rewrite'):
    if not dat:
        modify_info(filename,'','rewrite')
        return
    len_dat = len(dat)
    
    for i in range(len_dat):
        if i == 0:
            if order == 'rewrite':
                mode = 'rewrite'
            elif order == 'add':
                mode = 'add'
            else:
                print('wrong order')
        else:
            mode = 'add'
        if i == len_dat-1:
            new_line = 0
        else:
            new_line = 1
        modify_info(filename,bytearray(dat[i]),mode,new_line)
    gc.collect()
def get_using_times():
    return int(get_info(usfn,'line'))
def modify_using_times(num=1):
    n = get_using_times()
    if num == 0:
        return modify_info(usfn,0,'rewrite')
    return modify_info(usfn,n+1,'rewrite')

def get_ip():
    return get_info(ipfn,'line')
def modify_ip(ip):
    return modify_info(ipfn,ip,'rewrite')

def get_port():
    return int(get_info(portfn,'line'))
def modify_port(port):
    return modify_info(portfn,port,'rewrite')

def get_ls():
    return int(get_info(lsfn,'line'))
def modify_ls(ls):
    return modify_info(lsfn,ls,'rewrite')

def get_apn():
    return int(get_info(apnfn,'line'))
def modify_apn(apn):
    return modify_info(apnfn,apn,'rewrite')

def get_id():
    return get_info(idfn,'line')
def modify_id(local_id):
    return modify_info(idfn,local_id,'rewrite')

def get_pwd():
    return get_info(pwdfn,'line')
def modify_pwd(pwd):
    return modify_info(pwdfn,pwd,'rewrite')

def get_adimin_phone():
    return get_info(apfn,'all')
def modify_adimin_phone(ap):
    if len(ap) == GL.num_len:
        return modify_info(apfn,ap,'rewrite')
    if len(ap) == GL.num_len*2:
        modify_info(apfn,ap[:GL.num_len],'rewrite')
        modify_info(apfn,'\r\n','add')
        modify_info(apfn,ap[GL.num_len:],'add')

def get_emergency_open_card():
    n,card = get_info(eocfn,'all')
    return card[0][:-2],int(card[0][-2:])
def modify_emergency_open_card(eoc):
    return modify_info(eocfn,eoc,'rewrite')

def get_emergency_close_card():
    n,card = get_info(eccfn,'all')
    return card[0]
def modify_emergency_close_card(ecc):
    return modify_info(eccfn,ecc,'rewrite')

def get_gas_info():
    tmp_n,tmp_info = get_info(gifn,'all')
    if tmp_n == 0:
        return tmp_n,tmp_info
    if len(tmp_info[0]) > 59:
        n = int(len(tmp_info[0])/59)
        info = []
        for i in range(n):
            info.extend([tmp_info[0][i*59:i*59+59]])
        return [n,info]
    return tmp_n,tmp_info
def sub_ic_using_times():
    n,gas_info = get_gas_info()

def split_plus(d,n):
    return [d[i:i+n] for i in range(0,len(d),n)]
def modify_gas_info(gi):
    
    if gi == [] or gi == '':
        return modify_info(gifn,'','rewrite')
    if isinstance(gi,list):
        return _modify_gas_info(gi)
    pre_n,pre_info = get_gas_info()
    order = gi[0]
    num_of_gas = int(chr(gi[1]),10)
    if order == 48:
        mode = 'rewrite'
    elif order == 49:
        mode = 'add'
    else:
        print('write emergency data type is wrong')
        return None
    gas_data = gi[2:num_of_gas*59+2]
    if mode == 'add' and pre_n > 0:
        write_line_to_file(gifn,mode,'',1)

    modify_infos(gifn,split_plus(gas_data,59),mode)
    
    return 1
def _modify_gas_info(gi):
    n = len(gi)
    mode = 'rewrite'
    modify_infos(gifn,gi,mode)
    return 1
def get_gas_id():
    n,gas_info = get_gas_info()

    gas_id = []
    for i in gas_info:
        gas_id.extend([i[:6]])
    return str(n)+''.join([i for i in gas_id])

def get_swipe_record():
    return get_info(srfn,'all')
def modify_swipe_record(sr):
    if not sr:
        return clear_swipe_record()
    if not isinstance(sr,bytearray):
        sr = bytearray(sr)
    if sr == b'\r\n':
        return modify_info(srfn,sr,'add')
    sr[53+12] = 50
    return modify_info(srfn,sr,'add')
def clear_swipe_record():
    return modify_info(srfn,'','rewrite')

def get_sms_record():
    return get_info(smsfn,'all')
def modify_sms_record(sms):
    if not sms:
        return clear_sms_record()
    if not isinstance(sms,bytearray):
        sms = bytearray(sms)
    if sms == b'\r\n':
        return modify_info(smsfn,sms,'add')
    sms[53+12] = 50
    return modify_info(smsfn,sms,'add')
def clear_sms_record():
    return modify_info(smsfn,'','rewrite')

def get_power_down_record():
    return get_info(pdrfn,'all')
def modify_power_down_record(pdr):
    return modify_info(pdrfn,pdr,'add')
def clear_power_down_record():
    return modify_info(pdrfn,'','rewrite')

def get_lock_open_record():
    return get_info(lorfn,'all')
def modify_lock_open_record(lor):
    return modify_info(lorfn,lor,'add')
def clear_lock_open_record():
    return modify_info(lorfn,'','rewrite')


def get_control_open_record():
    return get_info(corfn,'all')
def modify_control_open_record(cor):
    return modify_info(corfn,cor,'add')
def clear_control_open_record():
    return modify_info(corfn,'','rewrite')


def get_pos_record_num():
    try:
        return int(get_info(prnfn,'line'))
    except:
        modify_info(prnfn,0,'rewrite')
        return 0
def modify_pos_record_nums(num = 1):
    n = get_pos_record_num()
    GL.debug_print('ggggggggggggggggggprn will be write is {}'.format(n))
    if num == 0:
        return modify_info(prnfn,0,'rewrite')
    elif num == 1:
        return modify_info(prnfn,n + 1,'rewrite')
    elif num == -1:
        if n >= 1:
            return modify_info(prnfn,n-1,'rewrite')

def get_pos_record(n=-1):
    if n <= 0:
        return get_pos_record_num()
    else:
        try:
            filename = '{:>07}'.format(n) + '.txt'
            with open(pos_path+'/'+filename, 'r') as f:
                line = f.readline()
                f.close()
                pyb.sync()
                return line
        except:
            return 0
def modify_pos_record(pos):
    if not pos:
        try:
            n = get_pos_record_num()
            if n > 0:
                for i in range(n):
                    filename = '{:>07}'.format(n) + '.txt'
                    os.remove(pos_path+'/'+filename)
                modify_pos_record_nums(0)
        except:
            os.mkdir(pos_path)
        return 1
    if isinstance(pos,bytes):
        pos = bytearray(pos)
    pos[53+12] = 50
    n = get_pos_record_num()+1
    modify_pos_record_nums()
    file_name = pos_path+'/'+'{:>07}'.format(n) + '.txt'
    return modify_info(file_name,pos,'rewrite')
def clear_pos_record(n):
    file_name = pos_path+'/'+'{:>07}'.format(n) + '.txt'
    os.remove(file_name)
    modify_pos_record_nums(-1)
    return 1

storage_basic0 = {'m_ls':modify_ls}
storage_basic1 = {'g_gas_info':get_gas_info,'m_emergency_card':modify_emergency_open_card,
'm_emergency_c_card':modify_emergency_close_card}


storage_gprs={'m_gas_info':modify_gas_info,'g_gas_id':get_gas_id,'writefile':write_file,
'g_emergency_card':get_emergency_open_card,'write_line':write_line_to_file,'m_ip':modify_ip,
'm_port':modify_port,'m_id':modify_id,'m_ap':modify_adimin_phone,'load_em':load_emergency_variable,
'm_pwd':modify_pwd,'m_sms':modify_sms_record,'m_using_times':modify_using_times}
storage_gprs.update(storage_basic0)
storage_gprs.update(storage_basic1)

storage_sys={'m_pos_record':modify_pos_record,'prep_dir':prepare_dir, 'prep_file':prepare_file, 'load':load_sys_variable,
'g_ls':get_ls,'save_em':save_emergency_variable,'del_group':del_one_group_emergency_variable,
'm_sw_record':modify_swipe_record,'g_using_times':get_using_times,'m_using_times':modify_using_times}
storage_sys.update(storage_basic0)
storage_sys.update(storage_basic1)


storage_main = {'m_pos_record':modify_pos_record,'g_ls':get_ls,'g_pos_record':get_pos_record,
'g_sw_record':get_swipe_record,'g_sms_record':get_sms_record,
'c_pos_record':clear_pos_record,'c_sw_record':clear_swipe_record,'c_sms_record':clear_sms_record}
storage_main.update(storage_basic0)