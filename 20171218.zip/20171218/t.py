from gu906 import MicropyGPRS,crc32
from storage import MicropySTORAGE
import GL
GL.N_lock = 12
my_gprs = MicropyGPRS()
my_storage = MicropySTORAGE()

a=b'~001685)\xed\xa0$nM*|\xd3\x9a\xaa\xa5`\xa8v&\xda\xf9C!~'
a=  b'~001681\xa4\xaer-\xb1\x9a\xa2\x97-=\xbbB\xcc\xfe(*\xd8/\xd8<~'
a=b'~001671\xb8-\x90\xd5\xafKM\xacRy\x8b\x9b\xc8\xae\x03\xd7\xcc\x8e&\xce~'
GL.locks_opreate = bytearray(b'111111111111')

b=[
b'000074A4E612E3A21474959934.795201113.5941251000111111111111',
b'000088B0000009A00000099934.720680113.7272320100111111111111',
b'000087B0000008A00000089934.720680113.7272320100111111111111',
b'000086B0000007A00000079934.720680113.7272320100111111111111',
b'000083B0000006A00000069934.720680113.7272320100111111111111',
b'00007933333333444444449934.742107113.7538930100111111111111',
b'000078B0000003A00000039934.746392113.6980540100111111111111',
b'000077B0000005A00000059934.765385113.6872760100111111111111',
b'00007655555555666666669934.746382113.6814610100111111111111',
b'00007533333333444444449934.742107113.7538930100111111111111'
]
#my_gprs.unpack_server_data(a)

filename = 'swipe_record.txt'
'''
my_storage.modify_info(filename,'')
for i in b:
    my_storage.modify_infos(filename,[i])

print('n_gas_info = {}'.format(my_storage.get_rows(filename)))
for i in my_storage.get_infos(filename):
    print(i)
'''
n_pos = my_storage.get_rows(filename)
print('n_gas_info = {}'.format(n_pos))
step  = 3
if n_pos:
    for i in range(step):
        if n_pos-i >= 1:
            info = my_storage.get_info(filename,n_pos-i)
            print(info)
            my_storage.del_rows(filename,n_pos-i)