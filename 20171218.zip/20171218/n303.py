#modify by wjy @20170106
#from math import floor
import GL
# Import pyb or time for fix time handling
try:
    # Assume running on pyboard
    import pyb
    GNSS_PORT = pyb.UART(2,9600,timeout=10,read_buf_len=64)
    gnss_reset_pin = pyb.Pin(pyb.Pin.cpu.B4, pyb.Pin.OUT_PP)
    battery_voltage = pyb.ADC(pyb.Pin.cpu.B1)
    vcc_voltage = pyb.ADC(pyb.Pin.cpu.B0)
    control_cover = pyb.ADC(pyb.Pin.cpu.A5)
    PINS = (gnss_reset_pin,battery_voltage,vcc_voltage,control_cover)

except ImportError:
    # Otherwise default to time module for non-embedded implementations
    # Note that this forces the resolution of the fix time 1 second instead
    # of milliseconds as on the pyboard
    import time
    GNSS_PORT = ''
    PINS = (1,2,3,4)


def int2bcd(a):
    '''int to bcd code'''
    return (a>>4)*10+ (a & 0x0f)
def bcd2int(a):
    '''bcd code to int'''
    return hex(((a / 10)<<4)+(a % 10))



class MicropyGNSS(object):
    """GPS NMEA Sentence Parser. Creates object that stores all relevant GPS data and statistics.
    Parses sentences one character at a time using update().

    """

    # Max Number of Characters a valid sentence can be (based on GGA sentence)
    SENTENCE_LIMIT = 76
    #__HEMISPHERES.keys() = ('N', 'S', 'E', 'W')
    __HEMISPHERES = {'N':b'1', 'S':b'2', 'E':b'1', 'W':b'2'}
    #__FIELD_LENGTH = (1,8,8,1,9,1,10,4,3,6,2,1,1,1,1,1,1,1,1,1) #the length of each field

    def __init__(self, local_offset=0):
        '''
        Setup GPS Object Status Flags, Internal Data Registers, etc
        '''

        GL.g = 0

        GL.vcc_below_14V = False
        GL.locks_on_checks_vcc19V = False
        GL.locks_off = False
        # Position/Motion
        #GL.speed_kmh = 0
        #GL.latitude = 0.0
        #GL.longitude = 0.0
        ######################
        self.gnss_port = GNSS_PORT
        self.gnss_reset = PINS[0]
        self.gnss_reset.low()
        self.battery_voltage = PINS[1]
        self.vcc_voltage = PINS[2]
        self.control_cover = PINS[3]
        #####################
        # Object Status Flags
        self.sentence_active = False
        self.active_segment = 0
        self.process_crc = False
        self.gps_segments = []
        self.crc_xor = 0
        self.char_count = 0
        self.fix_time = 0

        #####################
        # Sentence Statistics
        self.crc_fails = 0
        self.clean_sentences = 0
        self.parsed_sentences = 0


        #####################
        # Data From Sentences
        self.local_offset = local_offset


        # GPS Info
        #self.satellites_in_view = 0
        #self.hdop = 0.0
        #self.pdop = 0.0
        #self.vdop = 0.0
        self.valid = False
        #self.fix_stat = 0

        self.speed_1_times = 0

        # update status
        self.update_gnrmc = False
        self.update_gngga = False

        # clear buf
        self.clear_buf()
        GL.debug_print('gnss init is finished...')

    def clear_buf(self):
        try:
            GL.gnss_buf = bytearray('216-06-0320:08:0023447.9072111335.68360123000000.00001111*****', 'utf-8')
        except:
            GL.gnss_buf = bytearray('216-06-0320:08:0023447.9072111335.68360123000000.00001111*****')
        '''
        #length of gnss_buf is 62
        GL.gnss_buf = ['0']*20
        GL.gnss_buf[0] = '2' # 2-invalid 1-valid
        GL.gnss_buf[1] = '16-06-03' # date
        GL.gnss_buf[2] = '20:08:00' # time
        GL.gnss_buf[3] = '2' # 1--S 2--N
        GL.gnss_buf[4] = '3447.9072' # Latitude
        GL.gnss_buf[5] = '1' # 1-E 2-W
        GL.gnss_buf[6] = '11335.6836' # Longitude
        GL.gnss_buf[7] = '0123' # altitude
        GL.gnss_buf[8] = '000' # speed Km/h
        GL.gnss_buf[9] = '000.00' # course
        GL.gnss_buf[10] = '00' # num of satellite
        GL.gnss_buf[11] = '1' # runtime data-1 not runtime data-2
        GL.gnss_buf[12] = '1' # control_cover 1- close 2-open
        GL.gnss_buf[13] = '1' # lock power 0-power off 1-power on
        GL.gnss_buf[14] = '1' # main power 0-power off 1-power on
        GL.gnss_buf[15] = '*' # reserve 1
        GL.gnss_buf[16] = '*' # reserve 2
        GL.gnss_buf[17] = '*' # reserve 3
        GL.gnss_buf[18] = '*' # reserve 4
        GL.gnss_buf[19] = '*' # reserve 5
        '''

    ########################################
    # Sentence Parsers
    ########################################

    def gngga(self):
        """Parse Global Positioning System Fix Data (GGA) Sentence. Updates UTC timestamp, latitude, longitude,
        fix status, satellites in use, Horizontal Dilution of Precision (HDOP), altitude, geoid height and fix status"""
        self.update_gngga = False
        try:
            # UTC Timestamp
            utc_string = self.gps_segments[1]

            # Skip timestamp if receiver doesn't have on yet
            if utc_string:
                hours = int(utc_string[0:2]) + self.local_offset
                minutes = int(utc_string[2:4])
                seconds = float(utc_string[4:])
                tmp = (utc_string[0:2]+':'+utc_string[2:4]+':'+utc_string[4:6]).encode()
                if len(tmp) == 8:
                    GL.gnss_buf[9:17] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 9-17'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[9:17] = {}'.format((utc_string[0:2]+':'+utc_string[2:4]+':'+utc_string[4:6]).encode()))
                    self.clear_buf()
                '''
            # Number of Satellites in Use
            tmp = self.gps_segments[7].encode()
            if len(tmp) == 2:
                GL.gnss_buf[51:53] = tmp
            '''
            if len(GL.gnss_buf) != 62:
                GL.debug_print('len(GL.gnss_buf) = {} after 51-53'.format(len(GL.gnss_buf)))
                GL.debug_print('GL.gnss_buf[51:53] = {}'.format(self.gps_segments[7].encode()))
                self.clear_buf()
            '''
            # Horizontal Dilution of Precision
            #hdop = float(self.gps_segments[8])

            # Get Fix Status
            fix_stat = int(self.gps_segments[6])
            #GL.gnss_buf[0:1] = self.gps_segments[6].encode()

        except ValueError:
            return False

        # Process Location and Speed Data if Fix is GOOD
        if fix_stat:
            # Longitude / Latitude
            GL.gnss_buf[0:1] = b'1'
            if not GL.g:
                GL.g = 1
                GL.lcd_update(0)
            try:
                # Latitude
                l_string = self.gps_segments[2]
                lat_degs = int(l_string[0:2])
                lat_mins = float(l_string[2:])
                lat_hemi = self.gps_segments[3]
                tmp = '{:0>09}'.format(self.gps_segments[2][:9]).encode()
                if len(tmp) == 9:
                    GL.gnss_buf[18:27] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 18-27'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[18:27] = {}'.format('{:0>09}'.format(self.gps_segments[2][:9]).encode()))
                    self.clear_buf()
                '''
                GL.gnss_buf[27:28] = self.__HEMISPHERES[lat_hemi]
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 27-28'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[27:28] = {}'.format(self.__HEMISPHERES[lat_hemi]))
                    self.clear_buf()
                '''
                #GL.latitude = float(bytes(GL.gnss_buf[18:27]).decode())
                # Longitude
                l_string = self.gps_segments[4]
                lon_degs = int(l_string[0:3])
                lon_mins = float(l_string[3:])
                lon_hemi = self.gps_segments[5]
                tmp = '{:0>010}'.format(self.gps_segments[4][:10]).encode()
                if len(tmp) == 10:
                    GL.gnss_buf[28:38] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 28:38'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[28:38] = {}'.format('{:0>010}'.format(self.gps_segments[4][:10]).encode()))
                    self.clear_buf()
                '''
                GL.gnss_buf[27:28] = self.__HEMISPHERES[lon_hemi]
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 27:28'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[27:28] = {}'.format(self.__HEMISPHERES[lon_hemi]))
                    self.clear_buf()
                '''
            except ValueError:
                return False

            if lat_hemi not in self.__HEMISPHERES.keys():
                return False

            if lon_hemi not in self.__HEMISPHERES.keys():
                return False

            # Altitude / Height Above Geoid
            try:
                altitude = float(self.gps_segments[9])
                tmp = '{:0>4}'.format(int(altitude)).encode()
                if len(tmp) == 4:
                    GL.gnss_buf[38:42] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 38:42'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[38:42] = {}'.format('{:0>4}'.format(int(altitude)).encode()))
                    self.clear_buf()
                '''
                #geoid_height = float(self.gps_segments[11])
            except ValueError:
                return False

            self.update_gngga = True
        else:
            GL.gnss_buf[0:1] = b'2'
            if GL.g:
                GL.g = 0
                GL.lcd_update(0)

        #self.hdop = hdop
        return True

    def gnrmc(self):
        """Parse Recommended Minimum Specific GPS/Transit data (RMC)Sentence. Updates UTC timestamp, latitude,
        longitude, Course, Speed, Date, and fix status"""
        self.update_gnrmc = False
        # UTC Timestamp
        try:
            utc_string = self.gps_segments[1]

            if utc_string:  # Possible timestamp found
                hours = int(utc_string[0:2]) + self.local_offset
                minutes = int(utc_string[2:4])
                seconds = float(utc_string[4:])
                self.timestamp = (hours, minutes, seconds)
                tmp = (utc_string[0:2]+':'+utc_string[2:4]+':'+utc_string[4:6]).encode()
                if len(tmp) == 8:
                    GL.gnss_buf[9:17] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 9:17'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[9:17] = {}'.format((utc_string[0:2]+':'+utc_string[2:4]+':'+utc_string[4:6]).encode()))
                    self.clear_buf()
                '''
            else:  # No Time stamp yet
                self.timestamp = (0, 0, 0)

        except ValueError:  # Bad Timestamp value present
            return False

        # Date stamp
        try:
            date_string = self.gps_segments[9]

            # Date string printer function assumes to be year >=2000,
            # date_string() must be supplied with the correct century argument to display correctly
            if date_string:  # Possible date stamp found
                day = int(date_string[0:2])
                month = int(date_string[2:4])
                year = int(date_string[4:6])
                self.date = (day, month, year)
                tmp = (date_string[4:6]+'-'+date_string[2:4]+'-'+date_string[0:2]).encode()
                if len(tmp) == 8:
                    GL.gnss_buf[1:9] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 1:9'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[1:9] = {}'.format((date_string[4:6]+'-'+date_string[2:4]+'-'+date_string[0:2]).encode()))
                    self.clear_buf()
                '''
            '''
            else:  # No Date stamp yet
                self.date = (0, 0, 0)
            '''
        except ValueError:  # Bad Date stamp value present
            return False

        # Check Receiver Data Valid Flag
        if self.gps_segments[2] == 'A':  # Data from Receiver is Valid/Has Fix
            GL.gnss_buf[0:1] = b'1'
            if not GL.g:
                GL.g = 1
                GL.lcd_update(0)

            # Longitude / Latitude
            try:
                # Latitude
                l_string = self.gps_segments[3]
                lat_degs = int(l_string[0:2])
                lat_mins = float(l_string[2:])
                lat_hemi = self.gps_segments[4]
                GL.gnss_buf[17:18] = self.__HEMISPHERES[lat_hemi]
                tmp = '{:>09}'.format(self.gps_segments[3][:9]).encode()
                if len(tmp) == 9:
                    GL.gnss_buf[18:27] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 18:27'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[18:27] = {}'.format('{:>09}'.format(self.gps_segments[3][:9]).encode()))
                    self.clear_buf()
                '''
                #print(GL.gnss_buf[18:27])
                #GL.latitude = float(bytes(GL.gnss_buf[18:27]).decode())
                # Longitude
                l_string = self.gps_segments[5]
                lon_degs = int(l_string[0:3])
                lon_mins = float(l_string[3:])
                lon_hemi = self.gps_segments[6]
                GL.gnss_buf[27:28] = self.__HEMISPHERES[lon_hemi]
                tmp = '{:>010}'.format(self.gps_segments[5][:10]).encode()
                if len(tmp) == 10:
                    GL.gnss_buf[28:38] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 28:38'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[28:38] = {}'.format('{:>010}'.format(self.gps_segments[5][:10]).encode()))
                    self.clear_buf()
                '''
                #GL.longitude = float(bytes(GL.gnss_buf[28:38]).decode())
            except ValueError:
                return False

            if lat_hemi not in self.__HEMISPHERES.keys():
                return False

            if lon_hemi not in self.__HEMISPHERES.keys():
                return False

            # Speed
            try:
                spd_knt = float(self.gps_segments[7])
                tmp = '{:>03}'.format(int(spd_knt * 1.852)).encode()
                if len(tmp) == 3:
                    GL.gnss_buf[42:45] = tmp
                    speed_kmh = int(bytes(GL.gnss_buf[42:45]).decode())
                    if speed_kmh < 0.1 and GL.speed_is_zero_with_30s < 35:
                        GL.speed_is_zero_with_30s += 1

                    if speed_kmh > 1 and self.speed_1_times>=1:
                        GL.debug_print('speed_kmh = {}'.format(speed_kmh))
                        GL.speed_is_zero_with_30s = 0
                        self.speed_1_times = 0
                    if self.speed_1_times < 1 and speed_kmh > 1:
                        self.speed_1_times += 1
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 42:45'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[42:45] = {}'.format('{:>03}'.format(int(spd_knt * 1.852)).encode()))
                    self.clear_buf()
                '''
            except ValueError:
                return False

            # Course
            try:
                course = float(self.gps_segments[8])
                tmp = ('%06.2f'%course).encode()
                if len(tmp) == 6:
                    GL.gnss_buf[45:51] = tmp
                '''
                if len(GL.gnss_buf) != 62:
                    GL.debug_print('len(GL.gnss_buf) = {} after 45:51'.format(len(GL.gnss_buf)))
                    GL.debug_print('GL.gnss_buf[45:51] = {}'.format(('%06.2f'%course).encode()))
                    self.clear_buf()
                '''
            except ValueError:
                return False


            self.valid = True
            self.update_gnrmc = True
            # Update Last Fix Time
            #self.new_fix_time()

        else:  # Clear Position Data if Sentence is 'Invalid'

            GL.gnss_buf[0:1] = b'2'
            if GL.g:
                GL.g = 0
                GL.lcd_update(0)

            self.valid = False

        return True


    ##########################################
    # Data Stream Handler Functions
    ##########################################
    def update_voltage(self):
        try:
            #GL.debug_print('update_voltage is begining..')
            if self.control_cover.read() > 3900:
                GL.gnss_buf[54:55] = b'2'
            if self.control_cover.read() < 300:
                GL.gnss_buf[54:55] = b'1'
            if self.vcc_voltage.read() < 1699: #14V
                #bat_en.value(1)
                GL.gnss_buf[56:57] = b'0'
                GL.vcc_below_14V = True
                #lock_gnss['lp_off']()
                #gprs.send_1003()
            else:
                GL.gnss_buf[56:57] = b'1'

            if self.vcc_voltage.read() > 2243: #19V
                GL.gnss_buf[56:57] = b'1'
                if GL.gnss_buf[56:57] == b'0':
                    GL.locks_on_checks_vcc19V = True
                    #lock_gnss['lp_ons']()
                    GL.lock_status = [1]*12
                    #lock_gnss['checks']()
            else:
                GL.gnss_buf[56:57] == b'0'

            if self.battery_voltage.read() < 1216: #10V
                GL.gnss_buf[55:56] = b'0'
                if GL.gnss_buf[56:57] == b'0':
                    #lock_gnss['lp_offs']()
                    GL.locks_off = True
            if self.battery_voltage.read() > 1316:
                GL.gnss_buf[55:56] = b'1'
            GL.debug_print('battery_voltage = {}'.format(self.battery_voltage.read()))
            GL.debug_print('vcc_voltage = {}'.format(self.vcc_voltage.read()))
            GL.debug_print('control_cover = {}'.format(self.control_cover.read()))
            GL.dog.feed()
        except:
            pass
    def new_sentence(self):
        """Adjust Object Flags in Preparation for a New Sentence"""
        self.gps_segments = ['']
        self.active_segment = 0
        self.crc_xor = 0
        self.sentence_active = True
        self.process_crc = True
        self.char_count = 0
    def update(self):
        try:
            GL.dog.feed()
            if self.gnss_reset.value() == 1:
                print('N303 is Invalid, Please make the gnss_reset low')
                return None

            tmp = self.gnss_port.readchar()
            if tmp < 0 :
                #print('N303 is Invalid')
                return None
            if self._update(chr(tmp)):
                return 1
            else:
                return 0
            '''
            if self.gnss_port.any() > 1:
                for i in range(self.gnss_port.readline()):
                    if self._update(chr(i)):
                        return 1
            return None
            '''
        except:
            return None


    def _update(self, new_char = 0):
        """Process a new input char and updates GPS object if necessary based on special characters ('$', ',', '*')
        Function builds a list of received string that are validate by CRC prior to parsing by the  appropriate
        sentence function. Returns sentence type on successful parse, None otherwise"""
        #GL.debug_print('GL.gnss_buf = {}'.format(GL.gnss_buf))
        valid_sentence = False

        # Validate new_char is a printable char
        ascii_char = ord(new_char)

        if 10 <= ascii_char <= 126:
            self.char_count += 1

            # Check if a new string is starting ($)
            if new_char == '$':
                self.new_sentence()
                return None

            elif self.sentence_active:

                # Check if sentence is ending (*)
                if new_char == '*':
                    self.process_crc = False
                    self.active_segment += 1
                    self.gps_segments.append('')
                    return None

                # Check if a section is ended (,), Create a new substring to feed
                # characters to
                elif new_char == ',':
                    self.active_segment += 1
                    self.gps_segments.append('')

                # Store All Other printable character and check CRC when ready
                else:
                    self.gps_segments[self.active_segment] += new_char

                    # When CRC input is disabled, sentence is nearly complete
                    if not self.process_crc:

                        if len(self.gps_segments[self.active_segment]) == 2:
                            try:
                                final_crc = int(self.gps_segments[self.active_segment], 16)
                                if self.crc_xor == final_crc:
                                    valid_sentence = True
                                else:
                                    self.crc_fails += 1
                            except ValueError:
                                pass  # CRC Value was deformed and could not have been correct

                # Update CRC
                if self.process_crc:
                    self.crc_xor ^= ascii_char

                # If a Valid Sentence Was received and it's a supported sentence, then parse it!!
                if valid_sentence:
                    self.clean_sentences += 1  # Increment clean sentences received
                    self.sentence_active = False  # Clear Active Processing Flag

                    if self.gps_segments[0] in self.supported_sentences:

                        # parse the Sentence Based on the message type, return True if parse is clean
                        if self.supported_sentences[self.gps_segments[0]](self):

                            # Let host know that the GPS object was updated by returning parsed sentence type
                            self.parsed_sentences += 1
                            #return self.gps_segments[0]
                            if self.update_gnrmc and self.update_gngga:
                                self.update_gnrmc = self.update_gngga = False
                                #return GL.gnss_buf
                                #self.update_voltage()
                                #GL.gnss_buf[57:58] = (int2bcd(GL.rssi)).to_bytes(1, 'little')
                                return 1
                # Check that the sentence buffer isn't filling up with Garage waiting for the sentence to complete
                if self.char_count > self.SENTENCE_LIMIT:
                    self.sentence_active = False

        # Tell Host no new sentence was parsed
        return None

    # All the currently supported NMEA sentences
    supported_sentences = {'GNRMC': gnrmc, 'GNGGA': gngga,'GPRMC':gnrmc, 'GPGGA':gngga}
    # supported_sentences_ = {'GNRMC': gnrmc, 'GNGGA': gngga, 'GNVTG': gnvtg, 'GNGSA': gngsa, 'GNGSV': gngsv,'GNGLL': gngll}

'''
def test():
    test_sentence = [b'$GPRMC,081836,A,3751.65,S,14507.36,E,000.0,360.0,130998,011.3,E*62\n',
                b'$GPGGA,180050.896,3749.1802,N,08338.7865,W,1,07,1.1,397.4,M,-32.5,M,,0000*6C\n'
                b'$GPVTG,232.9,T,,M,002.3,N,004.3,K,A*01\n'
                b'$GPGSV,3,1,12,28,72,355,39,01,52,063,33,17,51,272,44,08,46,184,38*74\n',
                b'$GPGLL,4916.45,N,12311.12,W,225444,A,*1D\n',
                b'$GPRMC,092751.000,A,5321.6802,N,00630.3371,W,0.06,31.66,280511,,,A*45\n']
    my_gps = MicropyGPS()
    for sentence in test_sentence:
        for y in sentence:
            buf = my_gps.update(chr(y))
            if buf:
                print(my_gps.gnss_buf)
        print('GL.latitude,GL.longitude = {},{}'.format(float(bytes(GL.gnss_buf[18:27]).decode()),float(bytes(GL.gnss_buf[28:38]).decode())))
        print('GL.speed_kmh= {}'.format(GL.speed_kmh))
'''
#test()